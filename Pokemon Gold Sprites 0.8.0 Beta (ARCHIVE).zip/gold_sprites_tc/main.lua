return function(mod)

    mod.content.pokemon:patch("BULBASAUR", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("BULBASAUR", {
        spriteFront = mod.assets:path("overrides/battle/front/bulbasaur.png"),
        spriteBack = mod.assets:path("overrides/battle/back/bulbasaurb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("IVYSAUR", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("IVYSAUR", {
        spriteFront = mod.assets:path("overrides/battle/front/ivysaur.png"),
        spriteBack = mod.assets:path("overrides/battle/back/ivysaurb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("VENUSAUR", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("VENUSAUR", {
        spriteFront = mod.assets:path("overrides/battle/front/venusaur.png"),
        spriteBack = mod.assets:path("overrides/battle/back/venusaurb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("CHARMANDER", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("CHARMANDER", {
        spriteFront = mod.assets:path("overrides/battle/front/charmander.png"),
        spriteBack = mod.assets:path("overrides/battle/back/charmanderb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("CHARMELEON", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("CHARMELEON", {
        spriteFront = mod.assets:path("overrides/battle/front/charmeleon.png"),
        spriteBack = mod.assets:path("overrides/battle/back/charmeleonb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("CHARIZARD", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("CHARIZARD", {
        spriteFront = mod.assets:path("overrides/battle/front/charizard.png"),
        spriteBack = mod.assets:path("overrides/battle/back/charizardb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("SQUIRTLE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("SQUIRTLE", {
        spriteFront = mod.assets:path("overrides/battle/front/squirtle.png"),
        spriteBack = mod.assets:path("overrides/battle/back/squirtleb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("WARTORTLE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("WARTORTLE", {
        spriteFront = mod.assets:path("overrides/battle/front/wartortle.png"),
        spriteBack = mod.assets:path("overrides/battle/back/wartortleb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("BLASTOISE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("BLASTOISE", {
        spriteFront = mod.assets:path("overrides/battle/front/blastoise.png"),
        spriteBack = mod.assets:path("overrides/battle/back/blastoiseb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("CATERPIE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("CATERPIE", {
        spriteFront = mod.assets:path("overrides/battle/front/caterpie.png"),
        spriteBack = mod.assets:path("overrides/battle/back/caterpieb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("METAPOD", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("METAPOD", {
        spriteFront = mod.assets:path("overrides/battle/front/metapod.png"),
        spriteBack = mod.assets:path("overrides/battle/back/metapodb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("BUTTERFREE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("BUTTERFREE", {
        spriteFront = mod.assets:path("overrides/battle/front/butterfree.png"),
        spriteBack = mod.assets:path("overrides/battle/back/butterfreeb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("WEEDLE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("WEEDLE", {
        spriteFront = mod.assets:path("overrides/battle/front/weedle.png"),
        spriteBack = mod.assets:path("overrides/battle/back/weedleb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("KAKUNA", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("KAKUNA", {
        spriteFront = mod.assets:path("overrides/battle/front/kakuna.png"),
        spriteBack = mod.assets:path("overrides/battle/back/kakunab.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("BEEDRILL", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("BEEDRILL", {
        spriteFront = mod.assets:path("overrides/battle/front/beedrill.png"),
        spriteBack = mod.assets:path("overrides/battle/back/beedrillb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("PIDGEY", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("PIDGEY", {
        spriteFront = mod.assets:path("overrides/battle/front/pidgey.png"),
        spriteBack = mod.assets:path("overrides/battle/back/pidgeyb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("PIDGEOTTO", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("PIDGEOTTO", {
        spriteFront = mod.assets:path("overrides/battle/front/pidgeotto.png"),
        spriteBack = mod.assets:path("overrides/battle/back/pidgeottob.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("PIDGEOT", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("PIDGEOT", {
        spriteFront = mod.assets:path("overrides/battle/front/pidgeot.png"),
        spriteBack = mod.assets:path("overrides/battle/back/pidgeotb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("RATTATA", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("RATTATA", {
        spriteFront = mod.assets:path("overrides/battle/front/rattata.png"),
        spriteBack = mod.assets:path("overrides/battle/back/rattatab.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("RATICATE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("RATICATE", {
        spriteFront = mod.assets:path("overrides/battle/front/raticate.png"),
        spriteBack = mod.assets:path("overrides/battle/back/raticateb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("SPEAROW", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("SPEAROW", {
        spriteFront = mod.assets:path("overrides/battle/front/spearow.png"),
        spriteBack = mod.assets:path("overrides/battle/back/spearowb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("FEAROW", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("FEAROW", {
        spriteFront = mod.assets:path("overrides/battle/front/fearow.png"),
        spriteBack = mod.assets:path("overrides/battle/back/fearowb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("EKANS", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("EKANS", {
        spriteFront = mod.assets:path("overrides/battle/front/ekans.png"),
        spriteBack = mod.assets:path("overrides/battle/back/ekansb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("ARBOK", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("ARBOK", {
        spriteFront = mod.assets:path("overrides/battle/front/arbok.png"),
        spriteBack = mod.assets:path("overrides/battle/back/arbokb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("PIKACHU", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("PIKACHU", {
        spriteFront = mod.assets:path("overrides/battle/front/pikachu.png"),
        spriteBack = mod.assets:path("overrides/battle/back/pikachub.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("RAICHU", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("RAICHU", {
        spriteFront = mod.assets:path("overrides/battle/front/raichu.png"),
        spriteBack = mod.assets:path("overrides/battle/back/raichub.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("SANDSHREW", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("SANDSHREW", {
        spriteFront = mod.assets:path("overrides/battle/front/sandshrew.png"),
        spriteBack = mod.assets:path("overrides/battle/back/sandshrewb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("SANDSLASH", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("SANDSLASH", {
        spriteFront = mod.assets:path("overrides/battle/front/sandslash.png"),
        spriteBack = mod.assets:path("overrides/battle/back/sandslashb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("NIDORAN_F", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("NIDORAN_F", {
        spriteFront = mod.assets:path("overrides/battle/front/nidoran_f.png"),
        spriteBack = mod.assets:path("overrides/battle/back/nidoran_fb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("NIDORINA", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("NIDORINA", {
        spriteFront = mod.assets:path("overrides/battle/front/nidorina.png"),
        spriteBack = mod.assets:path("overrides/battle/back/nidorinab.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("NIDOQUEEN", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("NIDOQUEEN", {
        spriteFront = mod.assets:path("overrides/battle/front/nidoqueen.png"),
        spriteBack = mod.assets:path("overrides/battle/back/nidoqueenb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("NIDORAN_M", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("NIDORAN_M", {
        spriteFront = mod.assets:path("overrides/battle/front/nidoran_m.png"),
        spriteBack = mod.assets:path("overrides/battle/back/nidoran_mb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("NIDORINO", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("NIDORINO", {
        spriteFront = mod.assets:path("overrides/battle/front/nidorino.png"),
        spriteBack = mod.assets:path("overrides/battle/back/nidorinob.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("NIDOKING", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("NIDOKING", {
        spriteFront = mod.assets:path("overrides/battle/front/nidoking.png"),
        spriteBack = mod.assets:path("overrides/battle/back/nidokingb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("CLEFAIRY", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("CLEFAIRY", {
        spriteFront = mod.assets:path("overrides/battle/front/clefairy.png"),
        spriteBack = mod.assets:path("overrides/battle/back/clefairyb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("CLEFABLE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("CLEFABLE", {
        spriteFront = mod.assets:path("overrides/battle/front/clefable.png"),
        spriteBack = mod.assets:path("overrides/battle/back/clefableb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("VULPIX", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("VULPIX", {
        spriteFront = mod.assets:path("overrides/battle/front/vulpix.png"),
        spriteBack = mod.assets:path("overrides/battle/back/vulpixb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("NINETALES", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("NINETALES", {
        spriteFront = mod.assets:path("overrides/battle/front/ninetales.png"),
        spriteBack = mod.assets:path("overrides/battle/back/ninetalesb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("JIGGLYPUFF", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("JIGGLYPUFF", {
        spriteFront = mod.assets:path("overrides/battle/front/jigglypuff.png"),
        spriteBack = mod.assets:path("overrides/battle/back/jigglypuffb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("WIGGLYTUFF", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("WIGGLYTUFF", {
        spriteFront = mod.assets:path("overrides/battle/front/wigglytuff.png"),
        spriteBack = mod.assets:path("overrides/battle/back/wigglytuffb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("ZUBAT", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("ZUBAT", {
        spriteFront = mod.assets:path("overrides/battle/front/zubat.png"),
        spriteBack = mod.assets:path("overrides/battle/back/zubatb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("GOLBAT", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("GOLBAT", {
        spriteFront = mod.assets:path("overrides/battle/front/golbat.png"),
        spriteBack = mod.assets:path("overrides/battle/back/golbatb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("ODDISH", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("ODDISH", {
        spriteFront = mod.assets:path("overrides/battle/front/oddish.png"),
        spriteBack = mod.assets:path("overrides/battle/back/oddishb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("GLOOM", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("GLOOM", {
        spriteFront = mod.assets:path("overrides/battle/front/gloom.png"),
        spriteBack = mod.assets:path("overrides/battle/back/gloomb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("VILEPLUME", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("VILEPLUME", {
        spriteFront = mod.assets:path("overrides/battle/front/vileplume.png"),
        spriteBack = mod.assets:path("overrides/battle/back/vileplumeb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("PARAS", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("PARAS", {
        spriteFront = mod.assets:path("overrides/battle/front/paras.png"),
        spriteBack = mod.assets:path("overrides/battle/back/parasb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("PARASECT", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("PARASECT", {
        spriteFront = mod.assets:path("overrides/battle/front/parasect.png"),
        spriteBack = mod.assets:path("overrides/battle/back/parasectb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("VENONAT", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("VENONAT", {
        spriteFront = mod.assets:path("overrides/battle/front/venonat.png"),
        spriteBack = mod.assets:path("overrides/battle/back/venonatb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("VENOMOTH", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("VENOMOTH", {
        spriteFront = mod.assets:path("overrides/battle/front/venomoth.png"),
        spriteBack = mod.assets:path("overrides/battle/back/venomothb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("DIGLETT", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("DIGLETT", {
        spriteFront = mod.assets:path("overrides/battle/front/diglett.png"),
        spriteBack = mod.assets:path("overrides/battle/back/diglettb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("DUGTRIO", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("DUGTRIO", {
        spriteFront = mod.assets:path("overrides/battle/front/dugtrio.png"),
        spriteBack = mod.assets:path("overrides/battle/back/dugtriob.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("MEOWTH", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MEOWTH", {
        spriteFront = mod.assets:path("overrides/battle/front/meowth.png"),
        spriteBack = mod.assets:path("overrides/battle/back/meowthb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("PERSIAN", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("PERSIAN", {
        spriteFront = mod.assets:path("overrides/battle/front/persian.png"),
        spriteBack = mod.assets:path("overrides/battle/back/persianb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("PSYDUCK", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("PSYDUCK", {
        spriteFront = mod.assets:path("overrides/battle/front/psyduck.png"),
        spriteBack = mod.assets:path("overrides/battle/back/psyduckb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("GOLDUCK", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("GOLDUCK", {
        spriteFront = mod.assets:path("overrides/battle/front/golduck.png"),
        spriteBack = mod.assets:path("overrides/battle/back/golduckb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("MANKEY", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MANKEY", {
        spriteFront = mod.assets:path("overrides/battle/front/mankey.png"),
        spriteBack = mod.assets:path("overrides/battle/back/mankeyb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("PRIMEAPE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("PRIMEAPE", {
        spriteFront = mod.assets:path("overrides/battle/front/primeape.png"),
        spriteBack = mod.assets:path("overrides/battle/back/primeapeb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("GROWLITHE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("GROWLITHE", {
        spriteFront = mod.assets:path("overrides/battle/front/growlithe.png"),
        spriteBack = mod.assets:path("overrides/battle/back/growlitheb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("ARCANINE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("ARCANINE", {
        spriteFront = mod.assets:path("overrides/battle/front/arcanine.png"),
        spriteBack = mod.assets:path("overrides/battle/back/arcanineb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("POLIWAG", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("POLIWAG", {
        spriteFront = mod.assets:path("overrides/battle/front/poliwag.png"),
        spriteBack = mod.assets:path("overrides/battle/back/poliwagb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("POLIWHIRL", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("POLIWHIRL", {
        spriteFront = mod.assets:path("overrides/battle/front/poliwhirl.png"),
        spriteBack = mod.assets:path("overrides/battle/back/poliwhirlb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("POLIWRATH", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("POLIWRATH", {
        spriteFront = mod.assets:path("overrides/battle/front/poliwrath.png"),
        spriteBack = mod.assets:path("overrides/battle/back/poliwrathb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("ABRA", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("ABRA", {
        spriteFront = mod.assets:path("overrides/battle/front/abra.png"),
        spriteBack = mod.assets:path("overrides/battle/back/abrab.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("KADABRA", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("KADABRA", {
        spriteFront = mod.assets:path("overrides/battle/front/kadabra.png"),
        spriteBack = mod.assets:path("overrides/battle/back/kadabrab.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("ALAKAZAM", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("ALAKAZAM", {
        spriteFront = mod.assets:path("overrides/battle/front/alakazam.png"),
        spriteBack = mod.assets:path("overrides/battle/back/alakazamb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("MACHOP", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MACHOP", {
        spriteFront = mod.assets:path("overrides/battle/front/machop.png"),
        spriteBack = mod.assets:path("overrides/battle/back/machopb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("MACHOKE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MACHOKE", {
        spriteFront = mod.assets:path("overrides/battle/front/machoke.png"),
        spriteBack = mod.assets:path("overrides/battle/back/machokeb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("MACHAMP", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MACHAMP", {
        spriteFront = mod.assets:path("overrides/battle/front/machamp.png"),
        spriteBack = mod.assets:path("overrides/battle/back/machampb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("BELLSPROUT", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("BELLSPROUT", {
        spriteFront = mod.assets:path("overrides/battle/front/bellsprout.png"),
        spriteBack = mod.assets:path("overrides/battle/back/bellsproutb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("WEEPINBELL", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("WEEPINBELL", {
        spriteFront = mod.assets:path("overrides/battle/front/weepinbell.png"),
        spriteBack = mod.assets:path("overrides/battle/back/weepinbellb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("VICTREEBEL", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("VICTREEBEL", {
        spriteFront = mod.assets:path("overrides/battle/front/victreebel.png"),
        spriteBack = mod.assets:path("overrides/battle/back/victreebelb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("TENTACOOL", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("TENTACOOL", {
        spriteFront = mod.assets:path("overrides/battle/front/tentacool.png"),
        spriteBack = mod.assets:path("overrides/battle/back/tentacoolb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("TENTACRUEL", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("TENTACRUEL", {
        spriteFront = mod.assets:path("overrides/battle/front/tentacruel.png"),
        spriteBack = mod.assets:path("overrides/battle/back/tentacruelb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("GEODUDE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("GEODUDE", {
        spriteFront = mod.assets:path("overrides/battle/front/geodude.png"),
        spriteBack = mod.assets:path("overrides/battle/back/geodudeb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("GRAVELER", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("GRAVELER", {
        spriteFront = mod.assets:path("overrides/battle/front/graveler.png"),
        spriteBack = mod.assets:path("overrides/battle/back/gravelerb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("GOLEM", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("GOLEM", {
        spriteFront = mod.assets:path("overrides/battle/front/golem.png"),
        spriteBack = mod.assets:path("overrides/battle/back/golemb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("PONYTA", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("PONYTA", {
        spriteFront = mod.assets:path("overrides/battle/front/ponyta.png"),
        spriteBack = mod.assets:path("overrides/battle/back/ponytab.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("RAPIDASH", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("RAPIDASH", {
        spriteFront = mod.assets:path("overrides/battle/front/rapidash.png"),
        spriteBack = mod.assets:path("overrides/battle/back/rapidashb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("SLOWPOKE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("SLOWPOKE", {
        spriteFront = mod.assets:path("overrides/battle/front/slowpoke.png"),
        spriteBack = mod.assets:path("overrides/battle/back/slowpokeb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("SLOWBRO", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("SLOWBRO", {
        spriteFront = mod.assets:path("overrides/battle/front/slowbro.png"),
        spriteBack = mod.assets:path("overrides/battle/back/slowbrob.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("MAGNEMITE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MAGNEMITE", {
        spriteFront = mod.assets:path("overrides/battle/front/magnemite.png"),
        spriteBack = mod.assets:path("overrides/battle/back/magnemiteb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("MAGNETON", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MAGNETON", {
        spriteFront = mod.assets:path("overrides/battle/front/magneton.png"),
        spriteBack = mod.assets:path("overrides/battle/back/magnetonb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("FARFETCHD", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("FARFETCHD", {
        spriteFront = mod.assets:path("overrides/battle/front/farfetchd.png"),
        spriteBack = mod.assets:path("overrides/battle/back/farfetchdb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("DODUO", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("DODUO", {
        spriteFront = mod.assets:path("overrides/battle/front/doduo.png"),
        spriteBack = mod.assets:path("overrides/battle/back/doduob.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("DODRIO", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("DODRIO", {
        spriteFront = mod.assets:path("overrides/battle/front/dodrio.png"),
        spriteBack = mod.assets:path("overrides/battle/back/dodriob.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("SEEL", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("SEEL", {
        spriteFront = mod.assets:path("overrides/battle/front/seel.png"),
        spriteBack = mod.assets:path("overrides/battle/back/seelb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("DEWGONG", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("DEWGONG", {
        spriteFront = mod.assets:path("overrides/battle/front/dewgong.png"),
        spriteBack = mod.assets:path("overrides/battle/back/dewgongb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("GRIMER", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("GRIMER", {
        spriteFront = mod.assets:path("overrides/battle/front/grimer.png"),
        spriteBack = mod.assets:path("overrides/battle/back/grimerb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("MUK", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MUK", {
        spriteFront = mod.assets:path("overrides/battle/front/muk.png"),
        spriteBack = mod.assets:path("overrides/battle/back/mukb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("SHELLDER", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("SHELLDER", {
        spriteFront = mod.assets:path("overrides/battle/front/shellder.png"),
        spriteBack = mod.assets:path("overrides/battle/back/shellderb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("CLOYSTER", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("CLOYSTER", {
        spriteFront = mod.assets:path("overrides/battle/front/cloyster.png"),
        spriteBack = mod.assets:path("overrides/battle/back/cloysterb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("GASTLY", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("GASTLY", {
        spriteFront = mod.assets:path("overrides/battle/front/gastly.png"),
        spriteBack = mod.assets:path("overrides/battle/back/gastlyb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("HAUNTER", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("HAUNTER", {
        spriteFront = mod.assets:path("overrides/battle/front/haunter.png"),
        spriteBack = mod.assets:path("overrides/battle/back/haunterb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("GENGAR", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("GENGAR", {
        spriteFront = mod.assets:path("overrides/battle/front/gengar.png"),
        spriteBack = mod.assets:path("overrides/battle/back/gengarb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("ONIX", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("ONIX", {
        spriteFront = mod.assets:path("overrides/battle/front/onix.png"),
        spriteBack = mod.assets:path("overrides/battle/back/onixb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("DROWZEE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("DROWZEE", {
        spriteFront = mod.assets:path("overrides/battle/front/drowzee.png"),
        spriteBack = mod.assets:path("overrides/battle/back/drowzeeb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("HYPNO", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("HYPNO", {
        spriteFront = mod.assets:path("overrides/battle/front/hypno.png"),
        spriteBack = mod.assets:path("overrides/battle/back/hypnob.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("KRABBY", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("KRABBY", {
        spriteFront = mod.assets:path("overrides/battle/front/krabby.png"),
        spriteBack = mod.assets:path("overrides/battle/back/krabbyb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("KINGLER", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("KINGLER", {
        spriteFront = mod.assets:path("overrides/battle/front/kingler.png"),
        spriteBack = mod.assets:path("overrides/battle/back/kinglerb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("VOLTORB", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("VOLTORB", {
        spriteFront = mod.assets:path("overrides/battle/front/voltorb.png"),
        spriteBack = mod.assets:path("overrides/battle/back/voltorbb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("ELECTRODE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("ELECTRODE", {
        spriteFront = mod.assets:path("overrides/battle/front/electrode.png"),
        spriteBack = mod.assets:path("overrides/battle/back/electrodeb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("EXEGGCUTE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("EXEGGCUTE", {
        spriteFront = mod.assets:path("overrides/battle/front/exeggcute.png"),
        spriteBack = mod.assets:path("overrides/battle/back/exeggcuteb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("EXEGGUTOR", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("EXEGGUTOR", {
        spriteFront = mod.assets:path("overrides/battle/front/exeggutor.png"),
        spriteBack = mod.assets:path("overrides/battle/back/exeggutorb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("CUBONE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("CUBONE", {
        spriteFront = mod.assets:path("overrides/battle/front/cubone.png"),
        spriteBack = mod.assets:path("overrides/battle/back/cuboneb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("MAROWAK", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MAROWAK", {
        spriteFront = mod.assets:path("overrides/battle/front/marowak.png"),
        spriteBack = mod.assets:path("overrides/battle/back/marowakb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("HITMONLEE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("HITMONLEE", {
        spriteFront = mod.assets:path("overrides/battle/front/hitmonlee.png"),
        spriteBack = mod.assets:path("overrides/battle/back/hitmonleeb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("HITMONCHAN", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("HITMONCHAN", {
        spriteFront = mod.assets:path("overrides/battle/front/hitmonchan.png"),
        spriteBack = mod.assets:path("overrides/battle/back/hitmonchanb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("LICKITUNG", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("LICKITUNG", {
        spriteFront = mod.assets:path("overrides/battle/front/lickitung.png"),
        spriteBack = mod.assets:path("overrides/battle/back/lickitungb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("KOFFING", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("KOFFING", {
        spriteFront = mod.assets:path("overrides/battle/front/koffing.png"),
        spriteBack = mod.assets:path("overrides/battle/back/koffingb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("WEEZING", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("WEEZING", {
        spriteFront = mod.assets:path("overrides/battle/front/weezing.png"),
        spriteBack = mod.assets:path("overrides/battle/back/weezingb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("RHYHORN", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("RHYHORN", {
        spriteFront = mod.assets:path("overrides/battle/front/rhyhorn.png"),
        spriteBack = mod.assets:path("overrides/battle/back/rhyhornb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("RHYDON", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("RHYDON", {
        spriteFront = mod.assets:path("overrides/battle/front/rhydon.png"),
        spriteBack = mod.assets:path("overrides/battle/back/rhydonb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("CHANSEY", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("CHANSEY", {
        spriteFront = mod.assets:path("overrides/battle/front/chansey.png"),
        spriteBack = mod.assets:path("overrides/battle/back/chanseyb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("TANGELA", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("TANGELA", {
        spriteFront = mod.assets:path("overrides/battle/front/tangela.png"),
        spriteBack = mod.assets:path("overrides/battle/back/tangelab.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("KANGASKHAN", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("KANGASKHAN", {
        spriteFront = mod.assets:path("overrides/battle/front/kangaskhan.png"),
        spriteBack = mod.assets:path("overrides/battle/back/kangaskhanb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("HORSEA", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("HORSEA", {
        spriteFront = mod.assets:path("overrides/battle/front/horsea.png"),
        spriteBack = mod.assets:path("overrides/battle/back/horseab.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("SEADRA", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("SEADRA", {
        spriteFront = mod.assets:path("overrides/battle/front/seadra.png"),
        spriteBack = mod.assets:path("overrides/battle/back/seadrab.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("GOLDEEN", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("GOLDEEN", {
        spriteFront = mod.assets:path("overrides/battle/front/goldeen.png"),
        spriteBack = mod.assets:path("overrides/battle/back/goldeenb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("SEAKING", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("SEAKING", {
        spriteFront = mod.assets:path("overrides/battle/front/seaking.png"),
        spriteBack = mod.assets:path("overrides/battle/back/seakingb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("STARYU", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("STARYU", {
        spriteFront = mod.assets:path("overrides/battle/front/staryu.png"),
        spriteBack = mod.assets:path("overrides/battle/back/staryub.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("STARMIE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("STARMIE", {
        spriteFront = mod.assets:path("overrides/battle/front/starmie.png"),
        spriteBack = mod.assets:path("overrides/battle/back/starmieb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("MR_MIME", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MR_MIME", {
        spriteFront = mod.assets:path("overrides/battle/front/mr_mime.png"),
        spriteBack = mod.assets:path("overrides/battle/back/mr_mimeb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("SCYTHER", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("SCYTHER", {
        spriteFront = mod.assets:path("overrides/battle/front/scyther.png"),
        spriteBack = mod.assets:path("overrides/battle/back/scytherb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("JYNX", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("JYNX", {
        spriteFront = mod.assets:path("overrides/battle/front/jynx.png"),
        spriteBack = mod.assets:path("overrides/battle/back/jynxb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("ELECTABUZZ", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("ELECTABUZZ", {
        spriteFront = mod.assets:path("overrides/battle/front/electabuzz.png"),
        spriteBack = mod.assets:path("overrides/battle/back/electabuzzb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("MAGMAR", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MAGMAR", {
        spriteFront = mod.assets:path("overrides/battle/front/magmar.png"),
        spriteBack = mod.assets:path("overrides/battle/back/magmarb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("PINSIR", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("PINSIR", {
        spriteFront = mod.assets:path("overrides/battle/front/pinsir.png"),
        spriteBack = mod.assets:path("overrides/battle/back/pinsirb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("TAUROS", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("TAUROS", {
        spriteFront = mod.assets:path("overrides/battle/front/tauros.png"),
        spriteBack = mod.assets:path("overrides/battle/back/taurosb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("MAGIKARP", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MAGIKARP", {
        spriteFront = mod.assets:path("overrides/battle/front/magikarp.png"),
        spriteBack = mod.assets:path("overrides/battle/back/magikarpb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("GYARADOS", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("GYARADOS", {
        spriteFront = mod.assets:path("overrides/battle/front/gyarados.png"),
        spriteBack = mod.assets:path("overrides/battle/back/gyaradosb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("LAPRAS", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("LAPRAS", {
        spriteFront = mod.assets:path("overrides/battle/front/lapras.png"),
        spriteBack = mod.assets:path("overrides/battle/back/laprasb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("DITTO", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("DITTO", {
        spriteFront = mod.assets:path("overrides/battle/front/ditto.png"),
        spriteBack = mod.assets:path("overrides/battle/back/dittob.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("EEVEE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("EEVEE", {
        spriteFront = mod.assets:path("overrides/battle/front/eevee.png"),
        spriteBack = mod.assets:path("overrides/battle/back/eeveeb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("VAPOREON", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("VAPOREON", {
        spriteFront = mod.assets:path("overrides/battle/front/vaporeon.png"),
        spriteBack = mod.assets:path("overrides/battle/back/vaporeonb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("JOLTEON", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("JOLTEON", {
        spriteFront = mod.assets:path("overrides/battle/front/jolteon.png"),
        spriteBack = mod.assets:path("overrides/battle/back/jolteonb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("FLAREON", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("FLAREON", {
        spriteFront = mod.assets:path("overrides/battle/front/flareon.png"),
        spriteBack = mod.assets:path("overrides/battle/back/flareonb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("PORYGON", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("PORYGON", {
        spriteFront = mod.assets:path("overrides/battle/front/porygon.png"),
        spriteBack = mod.assets:path("overrides/battle/back/porygonb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("OMANYTE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("OMANYTE", {
        spriteFront = mod.assets:path("overrides/battle/front/omanyte.png"),
        spriteBack = mod.assets:path("overrides/battle/back/omanyteb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("OMASTAR", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("OMASTAR", {
        spriteFront = mod.assets:path("overrides/battle/front/omastar.png"),
        spriteBack = mod.assets:path("overrides/battle/back/omastarb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("KABUTO", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("KABUTO", {
        spriteFront = mod.assets:path("overrides/battle/front/kabuto.png"),
        spriteBack = mod.assets:path("overrides/battle/back/kabutob.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("KABUTOPS", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("KABUTOPS", {
        spriteFront = mod.assets:path("overrides/battle/front/kabutops.png"),
        spriteBack = mod.assets:path("overrides/battle/back/kabutopsb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("AERODACTYL", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("AERODACTYL", {
        spriteFront = mod.assets:path("overrides/battle/front/aerodactyl.png"),
        spriteBack = mod.assets:path("overrides/battle/back/aerodactylb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("SNORLAX", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("SNORLAX", {
        spriteFront = mod.assets:path("overrides/battle/front/snorlax.png"),
        spriteBack = mod.assets:path("overrides/battle/back/snorlaxb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("ARTICUNO", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("ARTICUNO", {
        spriteFront = mod.assets:path("overrides/battle/front/articuno.png"),
        spriteBack = mod.assets:path("overrides/battle/back/articunob.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("ZAPDOS", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("ZAPDOS", {
        spriteFront = mod.assets:path("overrides/battle/front/zapdos.png"),
        spriteBack = mod.assets:path("overrides/battle/back/zapdosb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("MOLTRES", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MOLTRES", {
        spriteFront = mod.assets:path("overrides/battle/front/moltres.png"),
        spriteBack = mod.assets:path("overrides/battle/back/moltresb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("DRATINI", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("DRATINI", {
        spriteFront = mod.assets:path("overrides/battle/front/dratini.png"),
        spriteBack = mod.assets:path("overrides/battle/back/dratinib.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("DRAGONAIR", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("DRAGONAIR", {
        spriteFront = mod.assets:path("overrides/battle/front/dragonair.png"),
        spriteBack = mod.assets:path("overrides/battle/back/dragonairb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("DRAGONITE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("DRAGONITE", {
        spriteFront = mod.assets:path("overrides/battle/front/dragonite.png"),
        spriteBack = mod.assets:path("overrides/battle/back/dragoniteb.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("MEWTWO", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MEWTWO", {
        spriteFront = mod.assets:path("overrides/battle/front/mewtwo.png"),
        spriteBack = mod.assets:path("overrides/battle/back/mewtwob.png"),
        trueColor = true
    })

    mod.content.pokemon:patch("MEW", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MEW", {
        spriteFront = mod.assets:path("overrides/battle/front/mew.png"),
        spriteBack = mod.assets:path("overrides/battle/back/mewb.png"),
        trueColor = true
    })
end