return function(mod)

    -- Truecolor --

      local SPRITES = {
        BULBASAUR = { front = "gold/battle/front/bulbasaur.png", back = "gold/battle/back/bulbasaurb.png" },
        IVYSAUR = { front = "gold/battle/front/ivysaur.png", back = "gold/battle/back/ivysaurb.png" },
        VENUSAUR = { front = "gold/battle/front/venusaur.png", back = "gold/battle/back/venusaurb.png" },
        CHARMANDER = { front = "gold/battle/front/charmander.png", back = "gold/battle/back/charmanderb.png" },
        CHARMELEON = { front = "gold/battle/front/charmeleon.png", back = "gold/battle/back/charmeleonb.png" },
        CHARIZARD = { front = "gold/battle/front/charizard.png", back = "gold/battle/back/charizardb.png" },
        SQUIRTLE = { front = "gold/battle/front/squirtle.png", back = "gold/battle/back/squirtleb.png" },
        WARTORTLE = { front = "gold/battle/front/wartortle.png", back = "gold/battle/back/wartortleb.png" },
        BLASTOISE = { front = "gold/battle/front/blastoise.png", back = "gold/battle/back/blastoiseb.png" },
        CATERPIE = { front = "gold/battle/front/caterpie.png", back = "gold/battle/back/caterpieb.png" },
        METAPOD = { front = "gold/battle/front/metapod.png", back = "gold/battle/back/metapodb.png" },
        BUTTERFREE = { front = "gold/battle/front/butterfree.png", back = "gold/battle/back/butterfreeb.png" },
        WEEDLE = { front = "gold/battle/front/weedle.png", back = "gold/battle/back/weedleb.png" },
        KAKUNA = { front = "gold/battle/front/kakuna.png", back = "gold/battle/back/kakunab.png" },
        BEEDRILL = { front = "gold/battle/front/beedrill.png", back = "gold/battle/back/beedrillb.png" },
        PIDGEY = { front = "gold/battle/front/pidgey.png", back = "gold/battle/back/pidgeyb.png" },
        PIDGEOTTO = { front = "gold/battle/front/pidgeotto.png", back = "gold/battle/back/pidgeottob.png" },
        PIDGEOT = { front = "gold/battle/front/pidgeot.png", back = "gold/battle/back/pidgeotb.png" },
        RATTATA = { front = "gold/battle/front/rattata.png", back = "gold/battle/back/rattatab.png" },
        RATICATE = { front = "gold/battle/front/raticate.png", back = "gold/battle/back/raticateb.png" },
        SPEAROW = { front = "gold/battle/front/spearow.png", back = "gold/battle/back/spearowb.png" },
        FEAROW = { front = "gold/battle/front/fearow.png", back = "gold/battle/back/fearowb.png" },
        EKANS = { front = "gold/battle/front/ekans.png", back = "gold/battle/back/ekansb.png" },
        ARBOK = { front = "gold/battle/front/arbok.png", back = "gold/battle/back/arbokb.png" },
        PIKACHU = { front = "gold/battle/front/pikachu.png", back = "gold/battle/back/pikachub.png" },
        RAICHU = { front = "gold/battle/front/raichu.png", back = "gold/battle/back/raichub.png" },
        SANDSHREW = { front = "gold/battle/front/sandshrew.png", back = "gold/battle/back/sandshrewb.png" },
        SANDSLASH = { front = "gold/battle/front/sandslash.png", back = "gold/battle/back/sandslashb.png" },
        NIDORAN_F = { front = "gold/battle/front/nidoran_f.png", back = "gold/battle/back/nidoran_fb.png" },
        NIDORINA = { front = "gold/battle/front/nidorina.png", back = "gold/battle/back/nidorinab.png" },
        NIDOQUEEN = { front = "gold/battle/front/nidoqueen.png", back = "gold/battle/back/nidoqueenb.png" },
        NIDORAN_M = { front = "gold/battle/front/nidoran_m.png", back = "gold/battle/back/nidoran_mb.png" },
        NIDORINO = { front = "gold/battle/front/nidorino.png", back = "gold/battle/back/nidorinob.png" },
        NIDOKING = { front = "gold/battle/front/nidoking.png", back = "gold/battle/back/nidokingb.png" },
        CLEFAIRY = { front = "gold/battle/front/clefairy.png", back = "gold/battle/back/clefairyb.png" },
        CLEFABLE = { front = "gold/battle/front/clefable.png", back = "gold/battle/back/clefableb.png" },
        VULPIX = { front = "gold/battle/front/vulpix.png", back = "gold/battle/back/vulpixb.png" },
        NINETALES = { front = "gold/battle/front/ninetales.png", back = "gold/battle/back/ninetalesb.png" },
        JIGGLYPUFF = { front = "gold/battle/front/jigglypuff.png", back = "gold/battle/back/jigglypuffb.png" },
        WIGGLYTUFF = { front = "gold/battle/front/wigglytuff.png", back = "gold/battle/back/wigglytuffb.png" },
        ZUBAT = { front = "gold/battle/front/zubat.png", back = "gold/battle/back/zubatb.png" },
        GOLBAT = { front = "gold/battle/front/golbat.png", back = "gold/battle/back/golbatb.png" },
        ODDISH = { front = "gold/battle/front/oddish.png", back = "gold/battle/back/oddishb.png" },
        GLOOM = { front = "gold/battle/front/gloom.png", back = "gold/battle/back/gloomb.png" },
        VILEPLUME = { front = "gold/battle/front/vileplume.png", back = "gold/battle/back/vileplumeb.png" },
        PARAS = { front = "gold/battle/front/paras.png", back = "gold/battle/back/parasb.png" },
        PARASECT = { front = "gold/battle/front/parasect.png", back = "gold/battle/back/parasectb.png" },
        VENONAT = { front = "gold/battle/front/venonat.png", back = "gold/battle/back/venonatb.png" },
        VENOMOTH = { front = "gold/battle/front/venomoth.png", back = "gold/battle/back/venomothb.png" },
        DIGLETT = { front = "gold/battle/front/diglett.png", back = "gold/battle/back/diglettb.png" },
        DUGTRIO = { front = "gold/battle/front/dugtrio.png", back = "gold/battle/back/dugtriob.png" },
        MEOWTH = { front = "gold/battle/front/meowth.png", back = "gold/battle/back/meowthb.png" },
        PERSIAN = { front = "gold/battle/front/persian.png", back = "gold/battle/back/persianb.png" },
        PSYDUCK = { front = "gold/battle/front/psyduck.png", back = "gold/battle/back/psyduckb.png" },
        GOLDUCK = { front = "gold/battle/front/golduck.png", back = "gold/battle/back/golduckb.png" },
        MANKEY = { front = "gold/battle/front/mankey.png", back = "gold/battle/back/mankeyb.png" },
        PRIMEAPE = { front = "gold/battle/front/primeape.png", back = "gold/battle/back/primeapeb.png" },
        GROWLITHE = { front = "gold/battle/front/growlithe.png", back = "gold/battle/back/growlitheb.png" },
        ARCANINE = { front = "gold/battle/front/arcanine.png", back = "gold/battle/back/arcanineb.png" },
        POLIWAG = { front = "gold/battle/front/poliwag.png", back = "gold/battle/back/poliwagb.png" },
        POLIWHIRL = { front = "gold/battle/front/poliwhirl.png", back = "gold/battle/back/poliwhirlb.png" },
        POLIWRATH = { front = "gold/battle/front/poliwrath.png", back = "gold/battle/back/poliwrathb.png" },
        ABRA = { front = "gold/battle/front/abra.png", back = "gold/battle/back/abrab.png" },
        KADABRA = { front = "gold/battle/front/kadabra.png", back = "gold/battle/back/kadabrab.png" },
        ALAKAZAM = { front = "gold/battle/front/alakazam.png", back = "gold/battle/back/alakazamb.png" },
        MACHOP = { front = "gold/battle/front/machop.png", back = "gold/battle/back/machopb.png" },
        MACHOKE = { front = "gold/battle/front/machoke.png", back = "gold/battle/back/machokeb.png" },
        MACHAMP = { front = "gold/battle/front/machamp.png", back = "gold/battle/back/machampb.png" },
        BELLSPROUT = { front = "gold/battle/front/bellsprout.png", back = "gold/battle/back/bellsproutb.png" },
        WEEPINBELL = { front = "gold/battle/front/weepinbell.png", back = "gold/battle/back/weepinbellb.png" },
        VICTREEBEL = { front = "gold/battle/front/victreebel.png", back = "gold/battle/back/victreebelb.png" },
        TENTACOOL = { front = "gold/battle/front/tentacool.png", back = "gold/battle/back/tentacoolb.png" },
        TENTACRUEL = { front = "gold/battle/front/tentacruel.png", back = "gold/battle/back/tentacruelb.png" },
        GEODUDE = { front = "gold/battle/front/geodude.png", back = "gold/battle/back/geodudeb.png" },
        GRAVELER = { front = "gold/battle/front/graveler.png", back = "gold/battle/back/gravelerb.png" },
        GOLEM = { front = "gold/battle/front/golem.png", back = "gold/battle/back/golemb.png" },
        PONYTA = { front = "gold/battle/front/ponyta.png", back = "gold/battle/back/ponytab.png" },
        RAPIDASH = { front = "gold/battle/front/rapidash.png", back = "gold/battle/back/rapidashb.png" },
        SLOWPOKE = { front = "gold/battle/front/slowpoke.png", back = "gold/battle/back/slowpokeb.png" },
        SLOWBRO = { front = "gold/battle/front/slowbro.png", back = "gold/battle/back/slowbrob.png" },
        MAGNEMITE = { front = "gold/battle/front/magnemite.png", back = "gold/battle/back/magnemiteb.png" },
        MAGNETON = { front = "gold/battle/front/magneton.png", back = "gold/battle/back/magnetonb.png" },
        FARFETCHD = { front = "gold/battle/front/farfetchd.png", back = "gold/battle/back/farfetchdb.png" },
        DODUO = { front = "gold/battle/front/doduo.png", back = "gold/battle/back/doduob.png" },
        DODRIO = { front = "gold/battle/front/dodrio.png", back = "gold/battle/back/dodriob.png" },
        SEEL = { front = "gold/battle/front/seel.png", back = "gold/battle/back/seelb.png" },
        DEWGONG = { front = "gold/battle/front/dewgong.png", back = "gold/battle/back/dewgongb.png" },
        GRIMER = { front = "gold/battle/front/grimer.png", back = "gold/battle/back/grimerb.png" },
        MUK = { front = "gold/battle/front/muk.png", back = "gold/battle/back/mukb.png" },
        SHELLDER = { front = "gold/battle/front/shellder.png", back = "gold/battle/back/shellderb.png" },
        CLOYSTER = { front = "gold/battle/front/cloyster.png", back = "gold/battle/back/cloysterb.png" },
        GASTLY = { front = "gold/battle/front/gastly.png", back = "gold/battle/back/gastlyb.png" },
        HAUNTER = { front = "gold/battle/front/haunter.png", back = "gold/battle/back/haunterb.png" },
        GENGAR = { front = "gold/battle/front/gengar.png", back = "gold/battle/back/gengarb.png" },
        ONIX = { front = "gold/battle/front/onix.png", back = "gold/battle/back/onixb.png" },
        DROWZEE = { front = "gold/battle/front/drowzee.png", back = "gold/battle/back/drowzeeb.png" },
        HYPNO = { front = "gold/battle/front/hypno.png", back = "gold/battle/back/hypnob.png" },
        KRABBY = { front = "gold/battle/front/krabby.png", back = "gold/battle/back/krabbyb.png" },
        KINGLER = { front = "gold/battle/front/kingler.png", back = "gold/battle/back/kinglerb.png" },
        VOLTORB = { front = "gold/battle/front/voltorb.png", back = "gold/battle/back/voltorbb.png" },
        ELECTRODE = { front = "gold/battle/front/electrode.png", back = "gold/battle/back/electrodeb.png" },
        EXEGGCUTE = { front = "gold/battle/front/exeggcute.png", back = "gold/battle/back/exeggcuteb.png" },
        EXEGGUTOR = { front = "gold/battle/front/exeggutor.png", back = "gold/battle/back/exeggutorb.png" },
        CUBONE = { front = "gold/battle/front/cubone.png", back = "gold/battle/back/cuboneb.png" },
        MAROWAK = { front = "gold/battle/front/marowak.png", back = "gold/battle/back/marowakb.png" },
        HITMONLEE = { front = "gold/battle/front/hitmonlee.png", back = "gold/battle/back/hitmonleeb.png" },
        HITMONCHAN = { front = "gold/battle/front/hitmonchan.png", back = "gold/battle/back/hitmonchanb.png" },
        LICKITUNG = { front = "gold/battle/front/lickitung.png", back = "gold/battle/back/lickitungb.png" },
        KOFFING = { front = "gold/battle/front/koffing.png", back = "gold/battle/back/koffingb.png" },
        WEEZING = { front = "gold/battle/front/weezing.png", back = "gold/battle/back/weezingb.png" },
        RHYHORN = { front = "gold/battle/front/rhyhorn.png", back = "gold/battle/back/rhyhornb.png" },
        RHYDON = { front = "gold/battle/front/rhydon.png", back = "gold/battle/back/rhydonb.png" },
        CHANSEY = { front = "gold/battle/front/chansey.png", back = "gold/battle/back/chanseyb.png" },
        TANGELA = { front = "gold/battle/front/tangela.png", back = "gold/battle/back/tangelab.png" },
        KANGASKHAN = { front = "gold/battle/front/kangaskhan.png", back = "gold/battle/back/kangaskhanb.png" },
        HORSEA = { front = "gold/battle/front/horsea.png", back = "gold/battle/back/horseab.png" },
        SEADRA = { front = "gold/battle/front/seadra.png", back = "gold/battle/back/seadrab.png" },
        GOLDEEN = { front = "gold/battle/front/goldeen.png", back = "gold/battle/back/goldeenb.png" },
        SEAKING = { front = "gold/battle/front/seaking.png", back = "gold/battle/back/seakingb.png" },
        STARYU = { front = "gold/battle/front/staryu.png", back = "gold/battle/back/staryub.png" },
        STARMIE = { front = "gold/battle/front/starmie.png", back = "gold/battle/back/starmieb.png" },
        MR_MIME = { front = "gold/battle/front/mr_mime.png", back = "gold/battle/back/mr_mimeb.png" },
        SCYTHER = { front = "gold/battle/front/scyther.png", back = "gold/battle/back/scytherb.png" },
        JYNX = { front = "gold/battle/front/jynx.png", back = "gold/battle/back/jynxb.png" },
        ELECTABUZZ = { front = "gold/battle/front/electabuzz.png", back = "gold/battle/back/electabuzzb.png" },
        MAGMAR = { front = "gold/battle/front/magmar.png", back = "gold/battle/back/magmarb.png" },
        PINSIR = { front = "gold/battle/front/pinsir.png", back = "gold/battle/back/pinsirb.png" },
        TAUROS = { front = "gold/battle/front/tauros.png", back = "gold/battle/back/taurosb.png" },
        MAGIKARP = { front = "gold/battle/front/magikarp.png", back = "gold/battle/back/magikarpb.png" },
        GYARADOS = { front = "gold/battle/front/gyarados.png", back = "gold/battle/back/gyaradosb.png" },
        LAPRAS = { front = "gold/battle/front/lapras.png", back = "gold/battle/back/laprasb.png" },
        DITTO = { front = "gold/battle/front/ditto.png", back = "gold/battle/back/dittob.png" },
        EEVEE = { front = "gold/battle/front/eevee.png", back = "gold/battle/back/eeveeb.png" },
        VAPOREON = { front = "gold/battle/front/vaporeon.png", back = "gold/battle/back/vaporeonb.png" },
        JOLTEON = { front = "gold/battle/front/jolteon.png", back = "gold/battle/back/jolteonb.png" },
        FLAREON = { front = "gold/battle/front/flareon.png", back = "gold/battle/back/flareonb.png" },
        PORYGON = { front = "gold/battle/front/porygon.png", back = "gold/battle/back/porygonb.png" },
        OMANYTE = { front = "gold/battle/front/omanyte.png", back = "gold/battle/back/omanyteb.png" },
        OMASTAR = { front = "gold/battle/front/omastar.png", back = "gold/battle/back/omastarb.png" },
        KABUTO = { front = "gold/battle/front/kabuto.png", back = "gold/battle/back/kabutob.png" },
        KABUTOPS = { front = "gold/battle/front/kabutops.png", back = "gold/battle/back/kabutopsb.png" },
        AERODACTYL = { front = "gold/battle/front/aerodactyl.png", back = "gold/battle/back/aerodactylb.png" },
        SNORLAX = { front = "gold/battle/front/snorlax.png", back = "gold/battle/back/snorlaxb.png" },
        ARTICUNO = { front = "gold/battle/front/articuno.png", back = "gold/battle/back/articunob.png" },
        ZAPDOS = { front = "gold/battle/front/zapdos.png", back = "gold/battle/back/zapdosb.png" },
        MOLTRES = { front = "gold/battle/front/moltres.png", back = "gold/battle/back/moltresb.png" },
        DRATINI = { front = "gold/battle/front/dratini.png", back = "gold/battle/back/dratinib.png" },
        DRAGONAIR = { front = "gold/battle/front/dragonair.png", back = "gold/battle/back/dragonairb.png" },
        DRAGONITE = { front = "gold/battle/front/dragonite.png", back = "gold/battle/back/dragoniteb.png" },
        MEWTWO = { front = "gold/battle/front/mewtwo.png", back = "gold/battle/back/mewtwob.png" },
        MEW = { front = "gold/battle/front/mew.png", back = "gold/battle/back/mewb.png" },
    }

    -- Grayscale --

    local GRAYSCALE_SPRITES = {
        BULBASAUR = { front = "bw/battle/front/bulbasaur.png", back = "bw/battle/back/bulbasaurb.png" },
        IVYSAUR = { front = "bw/battle/front/ivysaur.png", back = "bw/battle/back/ivysaurb.png" },
        VENUSAUR = { front = "bw/battle/front/venusaur.png", back = "bw/battle/back/venusaurb.png" },
        CHARMANDER = { front = "bw/battle/front/charmander.png", back = "bw/battle/back/charmanderb.png" },
        CHARMELEON = { front = "bw/battle/front/charmeleon.png", back = "bw/battle/back/charmeleonb.png" },
        CHARIZARD = { front = "bw/battle/front/charizard.png", back = "bw/battle/back/charizardb.png" },
        SQUIRTLE = { front = "bw/battle/front/squirtle.png", back = "bw/battle/back/squirtleb.png" },
        WARTORTLE = { front = "bw/battle/front/wartortle.png", back = "bw/battle/back/wartortleb.png" },
        BLASTOISE = { front = "bw/battle/front/blastoise.png", back = "bw/battle/back/blastoiseb.png" },
        CATERPIE = { front = "bw/battle/front/caterpie.png", back = "bw/battle/back/caterpieb.png" },
        METAPOD = { front = "bw/battle/front/metapod.png", back = "bw/battle/back/metapodb.png" },
        BUTTERFREE = { front = "bw/battle/front/butterfree.png", back = "bw/battle/back/butterfreeb.png" },
        WEEDLE = { front = "bw/battle/front/weedle.png", back = "bw/battle/back/weedleb.png" },
        KAKUNA = { front = "bw/battle/front/kakuna.png", back = "bw/battle/back/kakunab.png" },
        BEEDRILL = { front = "bw/battle/front/beedrill.png", back = "bw/battle/back/beedrillb.png" },
        PIDGEY = { front = "bw/battle/front/pidgey.png", back = "bw/battle/back/pidgeyb.png" },
        PIDGEOTTO = { front = "bw/battle/front/pidgeotto.png", back = "bw/battle/back/pidgeottob.png" },
        PIDGEOT = { front = "bw/battle/front/pidgeot.png", back = "bw/battle/back/pidgeotb.png" },
        RATTATA = { front = "bw/battle/front/rattata.png", back = "bw/battle/back/rattatab.png" },
        RATICATE = { front = "bw/battle/front/raticate.png", back = "bw/battle/back/raticateb.png" },
        SPEAROW = { front = "bw/battle/front/spearow.png", back = "bw/battle/back/spearowb.png" },
        FEAROW = { front = "bw/battle/front/fearow.png", back = "bw/battle/back/fearowb.png" },
        EKANS = { front = "bw/battle/front/ekans.png", back = "bw/battle/back/ekansb.png" },
        ARBOK = { front = "bw/battle/front/arbok.png", back = "bw/battle/back/arbokb.png" },
        PIKACHU = { front = "bw/battle/front/pikachu.png", back = "bw/battle/back/pikachub.png" },
        RAICHU = { front = "bw/battle/front/raichu.png", back = "bw/battle/back/raichub.png" },
        SANDSHREW = { front = "bw/battle/front/sandshrew.png", back = "bw/battle/back/sandshrewb.png" },
        SANDSLASH = { front = "bw/battle/front/sandslash.png", back = "bw/battle/back/sandslashb.png" },
        NIDORAN_F = { front = "bw/battle/front/nidoran_f.png", back = "bw/battle/back/nidoran_fb.png" },
        NIDORINA = { front = "bw/battle/front/nidorina.png", back = "bw/battle/back/nidorinab.png" },
        NIDOQUEEN = { front = "bw/battle/front/nidoqueen.png", back = "bw/battle/back/nidoqueenb.png" },
        NIDORAN_M = { front = "bw/battle/front/nidoran_m.png", back = "bw/battle/back/nidoran_mb.png" },
        NIDORINO = { front = "bw/battle/front/nidorino.png", back = "bw/battle/back/nidorinob.png" },
        NIDOKING = { front = "bw/battle/front/nidoking.png", back = "bw/battle/back/nidokingb.png" },
        CLEFAIRY = { front = "bw/battle/front/clefairy.png", back = "bw/battle/back/clefairyb.png" },
        CLEFABLE = { front = "bw/battle/front/clefable.png", back = "bw/battle/back/clefableb.png" },
        VULPIX = { front = "bw/battle/front/vulpix.png", back = "bw/battle/back/vulpixb.png" },
        NINETALES = { front = "bw/battle/front/ninetales.png", back = "bw/battle/back/ninetalesb.png" },
        JIGGLYPUFF = { front = "bw/battle/front/jigglypuff.png", back = "bw/battle/back/jigglypuffb.png" },
        WIGGLYTUFF = { front = "bw/battle/front/wigglytuff.png", back = "bw/battle/back/wigglytuffb.png" },
        ZUBAT = { front = "bw/battle/front/zubat.png", back = "bw/battle/back/zubatb.png" },
        GOLBAT = { front = "bw/battle/front/golbat.png", back = "bw/battle/back/golbatb.png" },
        ODDISH = { front = "bw/battle/front/oddish.png", back = "bw/battle/back/oddishb.png" },
        GLOOM = { front = "bw/battle/front/gloom.png", back = "bw/battle/back/gloomb.png" },
        VILEPLUME = { front = "bw/battle/front/vileplume.png", back = "bw/battle/back/vileplumeb.png" },
        PARAS = { front = "bw/battle/front/paras.png", back = "bw/battle/back/parasb.png" },
        PARASECT = { front = "bw/battle/front/parasect.png", back = "bw/battle/back/parasectb.png" },
        VENONAT = { front = "bw/battle/front/venonat.png", back = "bw/battle/back/venonatb.png" },
        VENOMOTH = { front = "bw/battle/front/venomoth.png", back = "bw/battle/back/venomothb.png" },
        DIGLETT = { front = "bw/battle/front/diglett.png", back = "bw/battle/back/diglettb.png" },
        DUGTRIO = { front = "bw/battle/front/dugtrio.png", back = "bw/battle/back/dugtriob.png" },
        MEOWTH = { front = "bw/battle/front/meowth.png", back = "bw/battle/back/meowthb.png" },
        PERSIAN = { front = "bw/battle/front/persian.png", back = "bw/battle/back/persianb.png" },
        PSYDUCK = { front = "bw/battle/front/psyduck.png", back = "bw/battle/back/psyduckb.png" },
        GOLDUCK = { front = "bw/battle/front/golduck.png", back = "bw/battle/back/golduckb.png" },
        MANKEY = { front = "bw/battle/front/mankey.png", back = "bw/battle/back/mankeyb.png" },
        PRIMEAPE = { front = "bw/battle/front/primeape.png", back = "bw/battle/back/primeapeb.png" },
        GROWLITHE = { front = "bw/battle/front/growlithe.png", back = "bw/battle/back/growlitheb.png" },
        ARCANINE = { front = "bw/battle/front/arcanine.png", back = "bw/battle/back/arcanineb.png" },
        POLIWAG = { front = "bw/battle/front/poliwag.png", back = "bw/battle/back/poliwagb.png" },
        POLIWHIRL = { front = "bw/battle/front/poliwhirl.png", back = "bw/battle/back/poliwhirlb.png" },
        POLIWRATH = { front = "bw/battle/front/poliwrath.png", back = "bw/battle/back/poliwrathb.png" },
        ABRA = { front = "bw/battle/front/abra.png", back = "bw/battle/back/abrab.png" },
        KADABRA = { front = "bw/battle/front/kadabra.png", back = "bw/battle/back/kadabrab.png" },
        ALAKAZAM = { front = "bw/battle/front/alakazam.png", back = "bw/battle/back/alakazamb.png" },
        MACHOP = { front = "bw/battle/front/machop.png", back = "bw/battle/back/machopb.png" },
        MACHOKE = { front = "bw/battle/front/machoke.png", back = "bw/battle/back/machokeb.png" },
        MACHAMP = { front = "bw/battle/front/machamp.png", back = "bw/battle/back/machampb.png" },
        BELLSPROUT = { front = "bw/battle/front/bellsprout.png", back = "bw/battle/back/bellsproutb.png" },
        WEEPINBELL = { front = "bw/battle/front/weepinbell.png", back = "bw/battle/back/weepinbellb.png" },
        VICTREEBEL = { front = "bw/battle/front/victreebel.png", back = "bw/battle/back/victreebelb.png" },
        TENTACOOL = { front = "bw/battle/front/tentacool.png", back = "bw/battle/back/tentacoolb.png" },
        TENTACRUEL = { front = "bw/battle/front/tentacruel.png", back = "bw/battle/back/tentacruelb.png" },
        GEODUDE = { front = "bw/battle/front/geodude.png", back = "bw/battle/back/geodudeb.png" },
        GRAVELER = { front = "bw/battle/front/graveler.png", back = "bw/battle/back/gravelerb.png" },
        GOLEM = { front = "bw/battle/front/golem.png", back = "bw/battle/back/golemb.png" },
        PONYTA = { front = "bw/battle/front/ponyta.png", back = "bw/battle/back/ponytab.png" },
        RAPIDASH = { front = "bw/battle/front/rapidash.png", back = "bw/battle/back/rapidashb.png" },
        SLOWPOKE = { front = "bw/battle/front/slowpoke.png", back = "bw/battle/back/slowpokeb.png" },
        SLOWBRO = { front = "bw/battle/front/slowbro.png", back = "bw/battle/back/slowbrob.png" },
        MAGNEMITE = { front = "bw/battle/front/magnemite.png", back = "bw/battle/back/magnemiteb.png" },
        MAGNETON = { front = "bw/battle/front/magneton.png", back = "bw/battle/back/magnetonb.png" },
        FARFETCHD = { front = "bw/battle/front/farfetchd.png", back = "bw/battle/back/farfetchdb.png" },
        DODUO = { front = "bw/battle/front/doduo.png", back = "bw/battle/back/doduob.png" },
        DODRIO = { front = "bw/battle/front/dodrio.png", back = "bw/battle/back/dodriob.png" },
        SEEL = { front = "bw/battle/front/seel.png", back = "bw/battle/back/seelb.png" },
        DEWGONG = { front = "bw/battle/front/dewgong.png", back = "bw/battle/back/dewgongb.png" },
        GRIMER = { front = "bw/battle/front/grimer.png", back = "bw/battle/back/grimerb.png" },
        MUK = { front = "bw/battle/front/muk.png", back = "bw/battle/back/mukb.png" },
        SHELLDER = { front = "bw/battle/front/shellder.png", back = "bw/battle/back/shellderb.png" },
        CLOYSTER = { front = "bw/battle/front/cloyster.png", back = "bw/battle/back/cloysterb.png" },
        GASTLY = { front = "bw/battle/front/gastly.png", back = "bw/battle/back/gastlyb.png" },
        HAUNTER = { front = "bw/battle/front/haunter.png", back = "bw/battle/back/haunterb.png" },
        GENGAR = { front = "bw/battle/front/gengar.png", back = "bw/battle/back/gengarb.png" },
        ONIX = { front = "bw/battle/front/onix.png", back = "bw/battle/back/onixb.png" },
        DROWZEE = { front = "bw/battle/front/drowzee.png", back = "bw/battle/back/drowzeeb.png" },
        HYPNO = { front = "bw/battle/front/hypno.png", back = "bw/battle/back/hypnob.png" },
        KRABBY = { front = "bw/battle/front/krabby.png", back = "bw/battle/back/krabbyb.png" },
        KINGLER = { front = "bw/battle/front/kingler.png", back = "bw/battle/back/kinglerb.png" },
        VOLTORB = { front = "bw/battle/front/voltorb.png", back = "bw/battle/back/voltorbb.png" },
        ELECTRODE = { front = "bw/battle/front/electrode.png", back = "bw/battle/back/electrodeb.png" },
        EXEGGCUTE = { front = "bw/battle/front/exeggcute.png", back = "bw/battle/back/exeggcuteb.png" },
        EXEGGUTOR = { front = "bw/battle/front/exeggutor.png", back = "bw/battle/back/exeggutorb.png" },
        CUBONE = { front = "bw/battle/front/cubone.png", back = "bw/battle/back/cuboneb.png" },
        MAROWAK = { front = "bw/battle/front/marowak.png", back = "bw/battle/back/marowakb.png" },
        HITMONLEE = { front = "bw/battle/front/hitmonlee.png", back = "bw/battle/back/hitmonleeb.png" },
        HITMONCHAN = { front = "bw/battle/front/hitmonchan.png", back = "bw/battle/back/hitmonchanb.png" },
        LICKITUNG = { front = "bw/battle/front/lickitung.png", back = "bw/battle/back/lickitungb.png" },
        KOFFING = { front = "bw/battle/front/koffing.png", back = "bw/battle/back/koffingb.png" },
        WEEZING = { front = "bw/battle/front/weezing.png", back = "bw/battle/back/weezingb.png" },
        RHYHORN = { front = "bw/battle/front/rhyhorn.png", back = "bw/battle/back/rhyhornb.png" },
        RHYDON = { front = "bw/battle/front/rhydon.png", back = "bw/battle/back/rhydonb.png" },
        CHANSEY = { front = "bw/battle/front/chansey.png", back = "bw/battle/back/chanseyb.png" },
        TANGELA = { front = "bw/battle/front/tangela.png", back = "bw/battle/back/tangelab.png" },
        KANGASKHAN = { front = "bw/battle/front/kangaskhan.png", back = "bw/battle/back/kangaskhanb.png" },
        HORSEA = { front = "bw/battle/front/horsea.png", back = "bw/battle/back/horseab.png" },
        SEADRA = { front = "bw/battle/front/seadra.png", back = "bw/battle/back/seadrab.png" },
        GOLDEEN = { front = "bw/battle/front/goldeen.png", back = "bw/battle/back/goldeenb.png" },
        SEAKING = { front = "bw/battle/front/seaking.png", back = "bw/battle/back/seakingb.png" },
        STARYU = { front = "bw/battle/front/staryu.png", back = "bw/battle/back/staryub.png" },
        STARMIE = { front = "bw/battle/front/starmie.png", back = "bw/battle/back/starmieb.png" },
        MR_MIME = { front = "bw/battle/front/mr_mime.png", back = "bw/battle/back/mr_mimeb.png" },
        SCYTHER = { front = "bw/battle/front/scyther.png", back = "bw/battle/back/scytherb.png" },
        JYNX = { front = "bw/battle/front/jynx.png", back = "bw/battle/back/jynxb.png" },
        ELECTABUZZ = { front = "bw/battle/front/electabuzz.png", back = "bw/battle/back/electabuzzb.png" },
        MAGMAR = { front = "bw/battle/front/magmar.png", back = "bw/battle/back/magmarb.png" },
        PINSIR = { front = "bw/battle/front/pinsir.png", back = "bw/battle/back/pinsirb.png" },
        TAUROS = { front = "bw/battle/front/tauros.png", back = "bw/battle/back/taurosb.png" },
        MAGIKARP = { front = "bw/battle/front/magikarp.png", back = "bw/battle/back/magikarpb.png" },
        GYARADOS = { front = "bw/battle/front/gyarados.png", back = "bw/battle/back/gyaradosb.png" },
        LAPRAS = { front = "bw/battle/front/lapras.png", back = "bw/battle/back/laprasb.png" },
        DITTO = { front = "bw/battle/front/ditto.png", back = "bw/battle/back/dittob.png" },
        EEVEE = { front = "bw/battle/front/eevee.png", back = "bw/battle/back/eeveeb.png" },
        VAPOREON = { front = "bw/battle/front/vaporeon.png", back = "bw/battle/back/vaporeonb.png" },
        JOLTEON = { front = "bw/battle/front/jolteon.png", back = "bw/battle/back/jolteonb.png" },
        FLAREON = { front = "bw/battle/front/flareon.png", back = "bw/battle/back/flareonb.png" },
        PORYGON = { front = "bw/battle/front/porygon.png", back = "bw/battle/back/porygonb.png" },
        OMANYTE = { front = "bw/battle/front/omanyte.png", back = "bw/battle/back/omanyteb.png" },
        OMASTAR = { front = "bw/battle/front/omastar.png", back = "bw/battle/back/omastarb.png" },
        KABUTO = { front = "bw/battle/front/kabuto.png", back = "bw/battle/back/kabutob.png" },
        KABUTOPS = { front = "bw/battle/front/kabutops.png", back = "bw/battle/back/kabutopsb.png" },
        AERODACTYL = { front = "bw/battle/front/aerodactyl.png", back = "bw/battle/back/aerodactylb.png" },
        SNORLAX = { front = "bw/battle/front/snorlax.png", back = "bw/battle/back/snorlaxb.png" },
        ARTICUNO = { front = "bw/battle/front/articuno.png", back = "bw/battle/back/articunob.png" },
        ZAPDOS = { front = "bw/battle/front/zapdos.png", back = "bw/battle/back/zapdosb.png" },
        MOLTRES = { front = "bw/battle/front/moltres.png", back = "bw/battle/back/moltresb.png" },
        DRATINI = { front = "bw/battle/front/dratini.png", back = "bw/battle/back/dratinib.png" },
        DRAGONAIR = { front = "bw/battle/front/dragonair.png", back = "bw/battle/back/dragonairb.png" },
        DRAGONITE = { front = "bw/battle/front/dragonite.png", back = "bw/battle/back/dragoniteb.png" },
        MEWTWO = { front = "bw/battle/front/mewtwo.png", back = "bw/battle/back/mewtwob.png" },
        MEW = { front = "bw/battle/front/mew.png", back = "bw/battle/back/mewb.png" },
    }

    -- Palette Colors --

    local PaletteFX = require("src.render.PaletteFX")
    local advancedPack = assert(PaletteFX.gbcPack(),
        "gold_sprites_tc: RED++ ADVANCED palette pack (data.palettes_gbc) is missing")

        advancedPack.palettes.BULBASAUR_PALETTE = {{255, 255, 255},  {90,214,99}, {255,82,49},  {0, 0, 0}, }
        advancedPack.palettes.IVYSAUR_PALETTE = {{255, 255, 255},  {99,189,99}, {214,82,115},  {0, 0, 0}, }
        advancedPack.palettes.VENUSAUR_PALETTE = {{255, 255, 255},  {82,181,99}, {214,82,115},  {0, 0, 0}, }
        advancedPack.palettes.CHARMANDER_PALETTE = {{255, 255, 255},  {255,148,33}, {181,90,41},  {0, 0, 0}, }
        advancedPack.palettes.CHARMELEON_PALETTE = {{255, 255, 255},  {255,115,41}, {189,74,82},  {0, 0, 0}, }
        advancedPack.palettes.CHARIZARD_PALETTE = {{255, 255, 255},  {90,140,214}, {255,140,49},  {0, 0, 0}, }
        advancedPack.palettes.SQUIRTLE_PALETTE = {{255, 255, 255},  {99,156,255}, {181, 148, 66},  {0, 0, 0}, }
        advancedPack.palettes.WARTORTLE_PALETTE = {{255, 255, 255},  {99,156,255}, {181,148,66},  {0, 0, 0}, }
        advancedPack.palettes.BLASTOISE_PALETTE = {{255, 255, 255},  {181,148,66}, {82,148,222},  {0, 0, 0}, }
        advancedPack.palettes.CATERPIE_PALETTE = {{255, 255, 255},  {99,181,49}, {255,99,140},  {0, 0, 0}, }
        advancedPack.palettes.METAPOD_PALETTE = {{255, 255, 255},  {123,255,0}, {74,115,8},  {0, 0, 0}, }
        advancedPack.palettes.BUTTERFREE_PALETTE = {{255, 255, 255},  {123,231,255}, {206,82,156},  {0, 0, 0}, }
        advancedPack.palettes.WEEDLE_PALETTE = {{255, 255, 255},  {239,214,41}, {214,57,0},  {0, 0, 0}, }
        advancedPack.palettes.KAKUNA_PALETTE = {{255, 255, 255},  {255,222,33}, {165,99,57},  {0, 0, 0}, }
        advancedPack.palettes.BEEDRILL_PALETTE = {{255, 255, 255},  {255,214,49}, {247,33,8},  {0, 0, 0}, }
        advancedPack.palettes.PIDGEY_PALETTE = {{255, 255, 255},  {255,173,255}, {156,66,16},  {0, 0, 0}, }
        advancedPack.palettes.PIDGEOTTO_PALETTE = {{255, 255, 255},  {255,123,189}, {156,66,16},  {0, 0, 0}, }
        advancedPack.palettes.PIDGEOT_PALETTE = {{255, 255, 255},  {255,123,189}, {156,66,16},  {0, 0, 0}, }
        advancedPack.palettes.RATTATA_PALETTE = {{255, 255, 255},  {181,123,247}, {148,74,140},  {0, 0, 0}, }
        advancedPack.palettes.RATICATE_PALETTE = {{255, 255, 255},  {214,132,24}, {115,66,24},  {0, 0, 0}, }
        advancedPack.palettes.SPEAROW_PALETTE = {{255, 255, 255},  {239,189,107}, {173,66,90},  {0, 0, 0}, }
        advancedPack.palettes.FEAROW_PALETTE = {{255, 255, 255},  {181,140,57}, {255,90,0},  {0, 0, 0}, }
        advancedPack.palettes.EKANS_PALETTE = {{255, 255, 255},  {255,107,189}, {189,24,140},  {0, 0, 0}, }
        advancedPack.palettes.ARBOK_PALETTE = {{255, 255, 255},  {156,99,214}, {99,33,156},  {0, 0, 0}, }
        advancedPack.palettes.PIKACHU_PALETTE = {{255, 255, 255},  {239,214,41}, {214,49,0},  {0, 0, 0}, }
        advancedPack.palettes.RAICHU_PALETTE = {{255, 255, 255},  {247,181,41}, {231,123,24},  {0, 0, 0}, }
        advancedPack.palettes.SANDSHREW_PALETTE = {{255, 255, 255},  {173,132,82}, {115,66,8},  {0, 0, 0}, }
        advancedPack.palettes.SANDSLASH_PALETTE = {{255, 255, 255},  {189,115,33}, {107,57,0},  {0, 0, 0}, }
        advancedPack.palettes.NIDORAN_F_PALETTE = {{255, 255, 255},  {156,173,255}, {57,132,49},  {0, 0, 0}, }
        advancedPack.palettes.NIDORINA_PALETTE = {{255, 255, 255},  {132,173,255}, {57,99,115},  {0, 0, 0}, }
        advancedPack.palettes.NIDOQUEEN_PALETTE = {{255, 255, 255},  {181,173,49}, {57,132,206},  {0, 0, 0}, }
        advancedPack.palettes.NIDORAN_M_PALETTE = {{255, 255, 255},  {222,140,181}, {173,16,66},  {0, 0, 0}, }
        advancedPack.palettes.NIDORINO_PALETTE = {{255, 255, 255},  {214,140,181}, {173,16,66},  {0, 0, 0}, }
        advancedPack.palettes.NIDOKING_PALETTE = {{255, 255, 255},  {198,82,156}, {107,24,123},  {0, 0, 0}, }
        advancedPack.palettes.CLEFAIRY_PALETTE = {{255, 255, 255},  {255,107,206}, {107,57,0},  {0, 0, 0}, }
        advancedPack.palettes.CLEFABLE_PALETTE = {{255, 255, 255},  {255,107,206}, {107,57,0},  {0, 0, 0}, }
        advancedPack.palettes.VULPIX_PALETTE = {{255, 255, 255},  {255,148,74}, {189,74,82},  {0, 0, 0}, }
        advancedPack.palettes.NINETALES_PALETTE = {{255, 255, 255},  {255,206,74}, {148,123,0},  {0, 0, 0}, }
        advancedPack.palettes.JIGGLYPUFF_PALETTE = {{255, 255, 255},  {255,132,255}, {49,132,255},  {0, 0, 0}, }
        advancedPack.palettes.WIGGLYTUFF_PALETTE = {{255, 255, 255},  {255,132,255}, {49,132,255},  {0, 0, 0}, }
        advancedPack.palettes.ZUBAT_PALETTE = {{255, 255, 255},  {123,123,222}, {49,57,99},  {0, 0, 0}, }
        advancedPack.palettes.GOLBAT_PALETTE = {{255, 255, 255},  {148,66,173}, {33,74,123},  {0, 0, 0}, }
        advancedPack.palettes.ODDISH_PALETTE = {{255, 255, 255},  {107,189,49}, {57,74,132},  {0, 0, 0}, }
        advancedPack.palettes.GLOOM_PALETTE = {{255, 255, 255},  {255,115,57}, {66,74,107},  {0, 0, 0}, }
        advancedPack.palettes.VILEPLUME_PALETTE = {{255, 255, 255},  {66,74,107}, {255,49,24},  {0, 0, 0}, }
        advancedPack.palettes.PARAS_PALETTE = {{255, 255, 255},  {255,99,24}, {231,57,49},  {0, 0, 0}, }
        advancedPack.palettes.PARASECT_PALETTE = {{255, 255, 255},  {255,156,66}, {148,74,24},  {0, 0, 0}, }
        advancedPack.palettes.VENONAT_PALETTE = {{255, 255, 255},  {231,198,255}, {90,0,115},  {0, 0, 0}, }
        advancedPack.palettes.VENOMOTH_PALETTE = {{255, 255, 255},  {214,181,255}, {148,132,189},  {0, 0, 0}, }
        advancedPack.palettes.DIGLETT_PALETTE = {{255, 255, 255},  {156,90,33}, {198,49,33},  {0, 0, 0}, }
        advancedPack.palettes.DUGTRIO_PALETTE = {{255, 255, 255},  {156,90,33}, {198,49,33},  {0, 0, 0}, }
        advancedPack.palettes.MEOWTH_PALETTE = {{255, 255, 255},  {255,255,41}, {231,82,41},  {0, 0, 0}, }
        advancedPack.palettes.PERSIAN_PALETTE = {{255, 255, 255},  {247,231,148}, {156,123,74},  {0, 0, 0}, }
        advancedPack.palettes.PSYDUCK_PALETTE = {{255, 255, 255},  {255,222,33}, {140,123,0},  {0, 0, 0}, }
        advancedPack.palettes.GOLDUCK_PALETTE = {{255, 255, 255},  {222,189,33}, {99,74,198},  {0, 0, 0}, }
        advancedPack.palettes.MANKEY_PALETTE = {{255, 255, 255},  {239,165,90}, {156,74,57},  {0, 0, 0}, }
        advancedPack.palettes.PRIMEAPE_PALETTE = {{255, 255, 255},  {255,123,49}, {115,74,33},  {0, 0, 0}, }
        advancedPack.palettes.GROWLITHE_PALETTE = {{255, 255, 255},  {255,148,57}, {132,66,24},  {0, 0, 0}, }
        advancedPack.palettes.ARCANINE_PALETTE = {{255, 255, 255},  {255,189,57}, {255,74,33},  {0, 0, 0}, }
        advancedPack.palettes.POLIWAG_PALETTE = {{255, 255, 255},  {214,66,140}, {66,41,123},  {0, 0, 0}, }
        advancedPack.palettes.POLIWHIRL_PALETTE = {{255, 255, 255},  {132,132,214}, {66,41,123},  {0, 0, 0}, }
        advancedPack.palettes.POLIWRATH_PALETTE = {{255, 255, 255},  {132,132,214}, {66,41,123},  {0, 0, 0}, }
        advancedPack.palettes.ABRA_PALETTE = {{255, 255, 255},  {231,156,24}, {99,66,82},  {0, 0, 0}, }
        advancedPack.palettes.KADABRA_PALETTE = {{255, 255, 255},  {231,156,24}, {99,66,82},  {0, 0, 0}, }
        advancedPack.palettes.ALAKAZAM_PALETTE = {{255, 255, 255},  {231,156,24}, {99,66,82},  {0, 0, 0}, }
        advancedPack.palettes.MACHOP_PALETTE = {{255, 255, 255},  {165,140,90}, {74,90,33},  {0, 0, 0}, }
        advancedPack.palettes.MACHOKE_PALETTE = {{255, 255, 255},  {132,140,90}, {181,33,33},  {0, 0, 0}, }
        advancedPack.palettes.MACHAMP_PALETTE = {{255, 255, 255},  {173,148,90}, {74,90,33},  {0, 0, 0}, }
        advancedPack.palettes.BELLSPROUT_PALETTE = {{255, 255, 255},  {165,255,57}, {222,82,74},  {0, 0, 0}, }
        advancedPack.palettes.WEEPINBELL_PALETTE = {{255, 255, 255},  {107,255,57}, {239,74,74},  {0, 0, 0}, }
        advancedPack.palettes.VICTREEBEL_PALETTE = {{255, 255, 255},  {240,195,200}, {148,198,74},  {0, 0, 0}, }
        advancedPack.palettes.TENTACOOL_PALETTE = {{255, 255, 255},  {90,165,255}, {247,49,82},  {0, 0, 0}, }
        advancedPack.palettes.TENTACRUEL_PALETTE = {{255, 255, 255},  {90,165,255}, {214,16,16},  {0, 0, 0}, }
        advancedPack.palettes.GEODUDE_PALETTE = {{255, 255, 255},  {148,140,123}, {66,90,57},  {0, 0, 0}, }
        advancedPack.palettes.GRAVELER_PALETTE = {{255, 255, 255},  {148,140,123}, {66,90,57},  {0, 0, 0}, }
        advancedPack.palettes.GOLEM_PALETTE = {{255, 255, 255},  {148,140,123}, {66,90,57},  {0, 0, 0}, }
        advancedPack.palettes.PONYTA_PALETTE = {{255, 255, 255},  {255,156,0}, {255,90,24},  {0, 0, 0}, }
        advancedPack.palettes.RAPIDASH_PALETTE = {{255, 255, 255},  {255,148,24}, {255,82,0},  {0, 0, 0}, }
        advancedPack.palettes.SLOWPOKE_PALETTE = {{255, 255, 255},  {247,165,198}, {231,49,115},  {0, 0, 0}, }
        advancedPack.palettes.SLOWBRO_PALETTE = {{255, 255, 255},  {247,165,198}, {198,189,156},  {0, 0, 0}, }
        advancedPack.palettes.MAGNEMITE_PALETTE = {{255, 255, 255},  {90,165,255}, {255,49,16},  {0, 0, 0}, }
        advancedPack.palettes.MAGNETON_PALETTE = {{255, 255, 255},  {90,165,255}, {255,49,16},  {0, 0, 0}, }
        advancedPack.palettes.FARFETCHD_PALETTE = {{255, 255, 255},  {198,165,115}, {132,99,57},  {0, 0, 0}, }
        advancedPack.palettes.DODUO_PALETTE = {{255, 255, 255},  {165,132,66}, {74,66,49},  {0, 0, 0}, }
        advancedPack.palettes.DODRIO_PALETTE = {{255, 255, 255},  {214,132,66}, {148,66,49},  {0, 0, 0}, }
        advancedPack.palettes.SEEL_PALETTE = {{255, 255, 255},  {156,173,255}, {239,90,148},  {0, 0, 0}, }
        advancedPack.palettes.DEWGONG_PALETTE = {{255, 255, 255},  {156,173,255}, {66,90,148},  {0, 0, 0}, }
        advancedPack.palettes.GRIMER_PALETTE = {{255, 255, 255},  {239,16,165}, {99,8,99},  {0, 0, 0}, }
        advancedPack.palettes.MUK_PALETTE = {{255, 255, 255},  {239,16,165}, {99,8,99},  {0, 0, 0}, }
        advancedPack.palettes.SHELLDER_PALETTE = {{255, 255, 255},  {148,140,165}, {173,90,115},  {0, 0, 0}, }
        advancedPack.palettes.CLOYSTER_PALETTE = {{255, 255, 255},  {156,82,206}, {74,33,107},  {0, 0, 0}, }
        advancedPack.palettes.GASTLY_PALETTE = {{255, 255, 255},  {247,107,247}, {140,0,189},  {0, 0, 0}, }
        advancedPack.palettes.HAUNTER_PALETTE = {{255, 255, 255},  {206,57,49}, {132,82,181},  {0, 0, 0}, }
        advancedPack.palettes.GENGAR_PALETTE = {{255, 255, 255},  {239,239,239}, {132,82,181},  {0, 0, 0}, }
        advancedPack.palettes.ONIX_PALETTE = {{255, 255, 255},  {189,148,140}, {74,49,90},  {0, 0, 0}, }
        advancedPack.palettes.DROWZEE_PALETTE = {{255, 255, 255},  {255,189,33}, {148,82,99},  {0, 0, 0}, }
        advancedPack.palettes.HYPNO_PALETTE = {{255, 255, 255},  {247,165,57}, {156,99,90},  {0, 0, 0}, }
        advancedPack.palettes.KRABBY_PALETTE = {{255, 255, 255},  {239,140,74}, {239,41,33},  {0, 0, 0}, }
        advancedPack.palettes.KINGLER_PALETTE = {{255, 255, 255},  {239,140,74}, {239,41,33},  {0, 0, 0}, }
        advancedPack.palettes.VOLTORB_PALETTE = {{255, 255, 255},  {206,189,140}, {255,74,66},  {0, 0, 0}, }
        advancedPack.palettes.ELECTRODE_PALETTE = {{255, 255, 255},  {206,189,140}, {255,74,66},  {0, 0, 0}, }
        advancedPack.palettes.EXEGGCUTE_PALETTE = {{255, 255, 255},  {255,123,214}, {156,99,74},  {0, 0, 0}, }
        advancedPack.palettes.EXEGGUTOR_PALETTE = {{255, 255, 255},  {214,132,49}, {41,132,57},  {0, 0, 0}, }
        advancedPack.palettes.CUBONE_PALETTE = {{255, 255, 255},  {181,132,90}, {115,66,33},  {0, 0, 0}, }
        advancedPack.palettes.MAROWAK_PALETTE = {{255, 255, 255},  {181,132,90}, {115,66,33},  {0, 0, 0}, }
        advancedPack.palettes.HITMONLEE_PALETTE = {{255, 255, 255},  {198,156,99}, {132,90,49},  {0, 0, 0}, }
        advancedPack.palettes.HITMONCHAN_PALETTE = {{255, 255, 255},  {173,123,99}, {222,24,148},  {0, 0, 0}, }
        advancedPack.palettes.LICKITUNG_PALETTE = {{255, 255, 255},  {255,82,148}, {214,49,41},  {0, 0, 0}, }
        advancedPack.palettes.KOFFING_PALETTE = {{255, 255, 255},  {206,82,206}, {148,49,148},  {0, 0, 0}, }
        advancedPack.palettes.WEEZING_PALETTE = {{255, 255, 255},  {206,82,206}, {148,49,148},  {0, 0, 0}, }
        advancedPack.palettes.RHYHORN_PALETTE = {{255, 255, 255},  {123,90,140}, {57,74,33},  {0, 0, 0}, }
        advancedPack.palettes.RHYDON_PALETTE = {{255, 255, 255},  {123,90,140}, {57,74,33},  {0, 0, 0}, }
        advancedPack.palettes.CHANSEY_PALETTE = {{255, 255, 255},  {222,156,189}, {255,66,173},  {0, 0, 0}, }
        advancedPack.palettes.TANGELA_PALETTE = {{255, 255, 255},  {8,255,198}, {140,49,49},  {0, 0, 0}, }
        advancedPack.palettes.KANGASKHAN_PALETTE = {{255, 255, 255},  {165,156,57}, {107,107,0},  {0, 0, 0}, }
        advancedPack.palettes.HORSEA_PALETTE = {{255, 255, 255},  {132,198,255}, {74,132,231},  {0, 0, 0}, }
        advancedPack.palettes.SEADRA_PALETTE = {{255, 255, 255},  {231,165,99}, {90,74,255},  {0, 0, 0}, }
        advancedPack.palettes.GOLDEEN_PALETTE = {{255, 255, 255},  {255,99,156}, {255,82,16},  {0, 0, 0}, }
        advancedPack.palettes.SEAKING_PALETTE = {{255, 255, 255},  {156,181,247}, {255,82,16},  {0, 0, 0}, }
        advancedPack.palettes.STARYU_PALETTE = {{255, 255, 255},  {189,140,90}, {255,41,24},  {0, 0, 0}, }
        advancedPack.palettes.STARMIE_PALETTE = {{255, 255, 255},  {214,181,0}, {156,57,148},  {0, 0, 0}, }
        advancedPack.palettes.MR_MIME_PALETTE = {{255, 255, 255},  {255,90,255}, {231,57,107},  {0, 0, 0}, }
        advancedPack.palettes.SCYTHER_PALETTE = {{255, 255, 255},  {123,214,0}, {189,206,0},  {0, 0, 0}, }
        advancedPack.palettes.JYNX_PALETTE = {{255, 255, 255},  {239,49,156}, {115,16,123},  {0, 0, 0}, }
        advancedPack.palettes.ELECTABUZZ_PALETTE = {{255, 255, 255},  {222,189,24}, {156,107,33},  {0, 0, 0}, }
        advancedPack.palettes.MAGMAR_PALETTE = {{255, 255, 255},  {255,165,0}, {189,74,82},  {0, 0, 0}, }
        advancedPack.palettes.PINSIR_PALETTE = {{255, 255, 255},  {148,173,148}, {132,90,57},  {0, 0, 0}, }
        advancedPack.palettes.TAUROS_PALETTE = {{255, 255, 255},  {255,198,41}, {156,115,74},  {0, 0, 0}, }
        advancedPack.palettes.MAGIKARP_PALETTE = {{255, 255, 255},  {255,132,49}, {214,82,24},  {0, 0, 0}, }
        advancedPack.palettes.GYARADOS_PALETTE = {{255, 255, 255},  {90,156,255}, {247,231,181},  {0, 0, 0}, }
        advancedPack.palettes.LAPRAS_PALETTE = {{255, 255, 255},  {231,173,107}, {66,132,231},  {0, 0, 0}, }
        advancedPack.palettes.DITTO_PALETTE = {{255, 255, 255},  {189,99,231}, {107,57,132},  {0, 0, 0}, }
        advancedPack.palettes.EEVEE_PALETTE = {{255, 255, 255},  {198,132,90}, {140,82,66},  {0, 0, 0}, }
        advancedPack.palettes.VAPOREON_PALETTE = {{255, 255, 255},  {132,181,255}, {74,90,255},  {0, 0, 0}, }
        advancedPack.palettes.JOLTEON_PALETTE = {{255, 255, 255},  {255,247,90}, {222,181,33},  {0, 0, 0}, }
        advancedPack.palettes.FLAREON_PALETTE = {{255, 255, 255},  {255,82,8}, {173,41,16},  {0, 0, 0}, }
        advancedPack.palettes.PORYGON_PALETTE = {{255, 255, 255},  {255,198,222}, {255,165,198},  {0, 0, 0}, }
        advancedPack.palettes.OMANYTE_PALETTE = {{255, 255, 255},  {189,165,82}, {74,90,189},  {0, 0, 0}, }
        advancedPack.palettes.OMASTAR_PALETTE = {{255, 255, 255},  {222,181,90}, {74,90,189},  {0, 0, 0}, }
        advancedPack.palettes.KABUTO_PALETTE = {{255, 255, 255},  {189,123,90}, {115,90,66},  {0, 0, 0}, }
        advancedPack.palettes.KABUTOPS_PALETTE = {{255, 255, 255},  {189,123,90}, {115,90,66},  {0, 0, 0}, }
        advancedPack.palettes.AERODACTYL_PALETTE = {{255, 255, 255},  {173,123,148}, {107,90,66},  {0, 0, 0}, }
        advancedPack.palettes.SNORLAX_PALETTE = {{255, 255, 255},  {90,123,123}, {239,222,181},  {0, 0, 0}, }
        advancedPack.palettes.ARTICUNO_PALETTE = {{255, 255, 255},  {90,173,255}, {66,90,132},  {0, 0, 0}, }
        advancedPack.palettes.ZAPDOS_PALETTE = {{255, 255, 255},  {255,231,0}, {189,132,0},  {0, 0, 0}, }
        advancedPack.palettes.MOLTRES_PALETTE = {{255, 255, 255},  {255,181,0}, {255,99,24},  {0, 0, 0}, }
        advancedPack.palettes.DRATINI_PALETTE = {{255, 255, 255},  {231,214,57}, {41,90,198},  {0, 0, 0}, }
        advancedPack.palettes.DRAGONAIR_PALETTE = {{255, 255, 255},  {115,156,255}, {41,90,255},  {0, 0, 0}, }
        advancedPack.palettes.DRAGONITE_PALETTE = {{255, 255, 255},  {173,148,49}, {90,82,140},  {0, 0, 0}, }
        advancedPack.palettes.MEWTWO_PALETTE = {{255, 255, 255},  {181,165,206}, {140,66,123},  {0, 0, 0}, }
        advancedPack.palettes.MEW_PALETTE = {{255, 255, 255},  {255,123,255}, {57,90,214},  {0, 0, 0}, }

       local ORIGINAL_ADVANCED_POKEMON = {}
    for id in pairs(GRAYSCALE_SPRITES) do
        ORIGINAL_ADVANCED_POKEMON[id] = advancedPack.pokemon[id]
    end

    
    -- Options --

       mod.options:define({
        { key = "spriteMode", label = "SPRITE DISPLAY", type = "choice",
          default = "both",
          choices = {
            { "BOTH", "both" },
            { "FRONT ONLY", "front" },
            { "BACK ONLY", "back" },
          } },
        { key = "colorMode", label = "COLOR MODE", type = "choice",
          default = "truecolor",
          choices = {
            { "TRUE COLOR", "truecolor" },
            { "GRAYSCALE", "grayscale" },
          } },
    })

       for id, entry in pairs(SPRITES) do
        mod.content.battle_sprite_scales:register(id .. "_back", {
            path = mod.assets:path(entry.back),
            scale = 1,
        })
    end
    for id, entry in pairs(GRAYSCALE_SPRITES) do
        mod.content.battle_sprite_scales:register(id .. "_back_gray", {
            path = mod.assets:path(entry.back),
            scale = 1,
        })
    end

       mod.hooks:wrap("pokemon.sprite", function(next, path, ctx)
        local tcEntry = SPRITES[ctx.species]
        local grayEntry = GRAYSCALE_SPRITES[ctx.species]
        if not tcEntry and not grayEntry then return next(path, ctx) end

        local mode = mod.options:get("spriteMode")
        local selected = (ctx.side == "front" and mode ~= "back")
            or (ctx.side == "back" and mode ~= "front")

        local colorMode = mod.options:get("colorMode")
        local useGray = selected and colorMode == "grayscale" and grayEntry ~= nil

        advancedPack.pokemon[ctx.species] = useGray
            and (ctx.species .. "_PALETTE")
            or ORIGINAL_ADVANCED_POKEMON[ctx.species]

        if not selected then
            ctx.trueColor = false
            return next(path, ctx)
        end

        if useGray then
            ctx.trueColor = false
            return mod.assets:path(ctx.side == "front" and grayEntry.front or grayEntry.back)
        end

        if not tcEntry then
            -- No true-color art for this species (shouldn't happen given
            -- both tables cover the same species, but fall back safely).
            ctx.trueColor = false
            return next(path, ctx)
        end

        ctx.trueColor = true
        return mod.assets:path(ctx.side == "front" and tcEntry.front or tcEntry.back)
    end)

end

