return function(mod)

    mod.content.pokemon:patch("BULBASAUR", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("BULBASAUR", {
        spriteFront = mod.assets:path("overrides/battle/front/bulbasaur.png"),
        spriteBack = mod.assets:path("overrides/battle/back/bulbasaurb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("IVYSAUR", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("IVYSAUR", {
        spriteFront = mod.assets:path("overrides/battle/front/ivysaur.png"),
        spriteBack = mod.assets:path("overrides/battle/back/ivysaurb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("VENUSAUR", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("VENUSAUR", {
        spriteFront = mod.assets:path("overrides/battle/front/venusaur.png"),
        spriteBack = mod.assets:path("overrides/battle/back/venusaurb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("CHARMANDER", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("CHARMANDER", {
        spriteFront = mod.assets:path("overrides/battle/front/charmander.png"),
        spriteBack = mod.assets:path("overrides/battle/back/charmanderb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("CHARMELEON", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("CHARMELEON", {
        spriteFront = mod.assets:path("overrides/battle/front/charmeleon.png"),
        spriteBack = mod.assets:path("overrides/battle/back/charmeleonb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("CHARIZARD", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("CHARIZARD", {
        spriteFront = mod.assets:path("overrides/battle/front/charizard.png"),
        spriteBack = mod.assets:path("overrides/battle/back/charizardb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("SQUIRTLE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("SQUIRTLE", {
        spriteFront = mod.assets:path("overrides/battle/front/squirtle.png"),
        spriteBack = mod.assets:path("overrides/battle/back/squirtleb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("WARTORTLE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("WARTORTLE", {
        spriteFront = mod.assets:path("overrides/battle/front/wartortle.png"),
        spriteBack = mod.assets:path("overrides/battle/back/wartortleb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("BLASTOISE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("BLASTOISE", {
        spriteFront = mod.assets:path("overrides/battle/front/blastoise.png"),
        spriteBack = mod.assets:path("overrides/battle/back/blastoiseb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("CATERPIE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("CATERPIE", {
        spriteFront = mod.assets:path("overrides/battle/front/caterpie.png"),
        spriteBack = mod.assets:path("overrides/battle/back/caterpieb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("METAPOD", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("METAPOD", {
        spriteFront = mod.assets:path("overrides/battle/front/metapod.png"),
        spriteBack = mod.assets:path("overrides/battle/back/metapodb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("BUTTERFREE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("BUTTERFREE", {
        spriteFront = mod.assets:path("overrides/battle/front/butterfree.png"),
        spriteBack = mod.assets:path("overrides/battle/back/butterfreeb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("WEEDLE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("WEEDLE", {
        spriteFront = mod.assets:path("overrides/battle/front/weedle.png"),
        spriteBack = mod.assets:path("overrides/battle/back/weedleb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("KAKUNA", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("KAKUNA", {
        spriteFront = mod.assets:path("overrides/battle/front/kakuna.png"),
        spriteBack = mod.assets:path("overrides/battle/back/kakunab.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("BEEDRILL", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("BEEDRILL", {
        spriteFront = mod.assets:path("overrides/battle/front/beedrill.png"),
        spriteBack = mod.assets:path("overrides/battle/back/beedrillb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("PIDGEY", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("PIDGEY", {
        spriteFront = mod.assets:path("overrides/battle/front/pidgey.png"),
        spriteBack = mod.assets:path("overrides/battle/back/pidgeyb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("PIDGEOTTO", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("PIDGEOTTO", {
        spriteFront = mod.assets:path("overrides/battle/front/pidgeotto.png"),
        spriteBack = mod.assets:path("overrides/battle/back/pidgeottob.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("PIDGEOT", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("PIDGEOT", {
        spriteFront = mod.assets:path("overrides/battle/front/pidgeot.png"),
        spriteBack = mod.assets:path("overrides/battle/back/pidgeotb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("RATTATA", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("RATTATA", {
        spriteFront = mod.assets:path("overrides/battle/front/rattata.png"),
        spriteBack = mod.assets:path("overrides/battle/back/rattatab.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("RATICATE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("RATICATE", {
        spriteFront = mod.assets:path("overrides/battle/front/raticate.png"),
        spriteBack = mod.assets:path("overrides/battle/back/raticateb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("SPEAROW", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("SPEAROW", {
        spriteFront = mod.assets:path("overrides/battle/front/spearow.png"),
        spriteBack = mod.assets:path("overrides/battle/back/spearowb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("FEAROW", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("FEAROW", {
        spriteFront = mod.assets:path("overrides/battle/front/fearow.png"),
        spriteBack = mod.assets:path("overrides/battle/back/fearowb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("EKANS", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("EKANS", {
        spriteFront = mod.assets:path("overrides/battle/front/ekans.png"),
        spriteBack = mod.assets:path("overrides/battle/back/ekansb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("ARBOK", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("ARBOK", {
        spriteFront = mod.assets:path("overrides/battle/front/arbok.png"),
        spriteBack = mod.assets:path("overrides/battle/back/arbokb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("PIKACHU", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("PIKACHU", {
        spriteFront = mod.assets:path("overrides/battle/front/pikachu.png"),
        spriteBack = mod.assets:path("overrides/battle/back/pikachub.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("RAICHU", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("RAICHU", {
        spriteFront = mod.assets:path("overrides/battle/front/raichu.png"),
        spriteBack = mod.assets:path("overrides/battle/back/raichub.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("SANDSHREW", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("SANDSHREW", {
        spriteFront = mod.assets:path("overrides/battle/front/sandshrew.png"),
        spriteBack = mod.assets:path("overrides/battle/back/sandshrewb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("SANDSLASH", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("SANDSLASH", {
        spriteFront = mod.assets:path("overrides/battle/front/sandslash.png"),
        spriteBack = mod.assets:path("overrides/battle/back/sandslashb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("NIDORAN_F", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("NIDORAN_F", {
        spriteFront = mod.assets:path("overrides/battle/front/nidoran_f.png"),
        spriteBack = mod.assets:path("overrides/battle/back/nidoran_fb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("NIDORINA", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("NIDORINA", {
        spriteFront = mod.assets:path("overrides/battle/front/nidorina.png"),
        spriteBack = mod.assets:path("overrides/battle/back/nidorinab.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("NIDOQUEEN", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("NIDOQUEEN", {
        spriteFront = mod.assets:path("overrides/battle/front/nidoqueen.png"),
        spriteBack = mod.assets:path("overrides/battle/back/nidoqueenb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("NIDORAN_M", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("NIDORAN_M", {
        spriteFront = mod.assets:path("overrides/battle/front/nidoran_m.png"),
        spriteBack = mod.assets:path("overrides/battle/back/nidoran_mb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("NIDORINO", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("NIDORINO", {
        spriteFront = mod.assets:path("overrides/battle/front/nidorino.png"),
        spriteBack = mod.assets:path("overrides/battle/back/nidorinob.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("NIDOKING", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("NIDOKING", {
        spriteFront = mod.assets:path("overrides/battle/front/nidoking.png"),
        spriteBack = mod.assets:path("overrides/battle/back/nidokingb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("CLEFAIRY", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("CLEFAIRY", {
        spriteFront = mod.assets:path("overrides/battle/front/clefairy.png"),
        spriteBack = mod.assets:path("overrides/battle/back/clefairyb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("CLEFABLE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("CLEFABLE", {
        spriteFront = mod.assets:path("overrides/battle/front/clefable.png"),
        spriteBack = mod.assets:path("overrides/battle/back/clefableb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("VULPIX", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("VULPIX", {
        spriteFront = mod.assets:path("overrides/battle/front/vulpix.png"),
        spriteBack = mod.assets:path("overrides/battle/back/vulpixb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("NINETALES", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("NINETALES", {
        spriteFront = mod.assets:path("overrides/battle/front/ninetales.png"),
        spriteBack = mod.assets:path("overrides/battle/back/ninetalesb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("JIGGLYPUFF", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("JIGGLYPUFF", {
        spriteFront = mod.assets:path("overrides/battle/front/jigglypuff.png"),
        spriteBack = mod.assets:path("overrides/battle/back/jigglypuffb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("WIGGLYTUFF", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("WIGGLYTUFF", {
        spriteFront = mod.assets:path("overrides/battle/front/wigglytuff.png"),
        spriteBack = mod.assets:path("overrides/battle/back/wigglytuffb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("ZUBAT", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("ZUBAT", {
        spriteFront = mod.assets:path("overrides/battle/front/zubat.png"),
        spriteBack = mod.assets:path("overrides/battle/back/zubatb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("GOLBAT", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("GOLBAT", {
        spriteFront = mod.assets:path("overrides/battle/front/golbat.png"),
        spriteBack = mod.assets:path("overrides/battle/back/golbatb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("ODDISH", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("ODDISH", {
        spriteFront = mod.assets:path("overrides/battle/front/oddish.png"),
        spriteBack = mod.assets:path("overrides/battle/back/oddishb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("GLOOM", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("GLOOM", {
        spriteFront = mod.assets:path("overrides/battle/front/gloom.png"),
        spriteBack = mod.assets:path("overrides/battle/back/gloomb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("VILEPLUME", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("VILEPLUME", {
        spriteFront = mod.assets:path("overrides/battle/front/vileplume.png"),
        spriteBack = mod.assets:path("overrides/battle/back/vileplumeb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("PARAS", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("PARAS", {
        spriteFront = mod.assets:path("overrides/battle/front/paras.png"),
        spriteBack = mod.assets:path("overrides/battle/back/parasb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("PARASECT", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("PARASECT", {
        spriteFront = mod.assets:path("overrides/battle/front/parasect.png"),
        spriteBack = mod.assets:path("overrides/battle/back/parasectb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("VENONAT", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("VENONAT", {
        spriteFront = mod.assets:path("overrides/battle/front/venonat.png"),
        spriteBack = mod.assets:path("overrides/battle/back/venonatb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("VENOMOTH", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("VENOMOTH", {
        spriteFront = mod.assets:path("overrides/battle/front/venomoth.png"),
        spriteBack = mod.assets:path("overrides/battle/back/venomothb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("DIGLETT", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("DIGLETT", {
        spriteFront = mod.assets:path("overrides/battle/front/diglett.png"),
        spriteBack = mod.assets:path("overrides/battle/back/diglettb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("DUGTRIO", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("DUGTRIO", {
        spriteFront = mod.assets:path("overrides/battle/front/dugtrio.png"),
        spriteBack = mod.assets:path("overrides/battle/back/dugtriob.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("MEOWTH", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MEOWTH", {
        spriteFront = mod.assets:path("overrides/battle/front/meowth.png"),
        spriteBack = mod.assets:path("overrides/battle/back/meowthb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("PERSIAN", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("PERSIAN", {
        spriteFront = mod.assets:path("overrides/battle/front/persian.png"),
        spriteBack = mod.assets:path("overrides/battle/back/persianb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("PSYDUCK", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("PSYDUCK", {
        spriteFront = mod.assets:path("overrides/battle/front/psyduck.png"),
        spriteBack = mod.assets:path("overrides/battle/back/psyduckb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("GOLDUCK", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("GOLDUCK", {
        spriteFront = mod.assets:path("overrides/battle/front/golduck.png"),
        spriteBack = mod.assets:path("overrides/battle/back/golduckb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("MANKEY", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MANKEY", {
        spriteFront = mod.assets:path("overrides/battle/front/mankey.png"),
        spriteBack = mod.assets:path("overrides/battle/back/mankeyb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("PRIMEAPE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("PRIMEAPE", {
        spriteFront = mod.assets:path("overrides/battle/front/primeape.png"),
        spriteBack = mod.assets:path("overrides/battle/back/primeapeb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("GROWLITHE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("GROWLITHE", {
        spriteFront = mod.assets:path("overrides/battle/front/growlithe.png"),
        spriteBack = mod.assets:path("overrides/battle/back/growlitheb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("ARCANINE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("ARCANINE", {
        spriteFront = mod.assets:path("overrides/battle/front/arcanine.png"),
        spriteBack = mod.assets:path("overrides/battle/back/arcanineb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("POLIWAG", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("POLIWAG", {
        spriteFront = mod.assets:path("overrides/battle/front/poliwag.png"),
        spriteBack = mod.assets:path("overrides/battle/back/poliwagb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("POLIWHIRL", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("POLIWHIRL", {
        spriteFront = mod.assets:path("overrides/battle/front/poliwhirl.png"),
        spriteBack = mod.assets:path("overrides/battle/back/poliwhirlb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("POLIWRATH", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("POLIWRATH", {
        spriteFront = mod.assets:path("overrides/battle/front/poliwrath.png"),
        spriteBack = mod.assets:path("overrides/battle/back/poliwrathb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("ABRA", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("ABRA", {
        spriteFront = mod.assets:path("overrides/battle/front/abra.png"),
        spriteBack = mod.assets:path("overrides/battle/back/abrab.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("KADABRA", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("KADABRA", {
        spriteFront = mod.assets:path("overrides/battle/front/kadabra.png"),
        spriteBack = mod.assets:path("overrides/battle/back/kadabrab.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("ALAKAZAM", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("ALAKAZAM", {
        spriteFront = mod.assets:path("overrides/battle/front/alakazam.png"),
        spriteBack = mod.assets:path("overrides/battle/back/alakazamb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("MACHOP", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MACHOP", {
        spriteFront = mod.assets:path("overrides/battle/front/machop.png"),
        spriteBack = mod.assets:path("overrides/battle/back/machopb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("MACHOKE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MACHOKE", {
        spriteFront = mod.assets:path("overrides/battle/front/machoke.png"),
        spriteBack = mod.assets:path("overrides/battle/back/machokeb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("MACHAMP", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MACHAMP", {
        spriteFront = mod.assets:path("overrides/battle/front/machamp.png"),
        spriteBack = mod.assets:path("overrides/battle/back/machampb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("BELLSPROUT", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("BELLSPROUT", {
        spriteFront = mod.assets:path("overrides/battle/front/bellsprout.png"),
        spriteBack = mod.assets:path("overrides/battle/back/bellsproutb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("WEEPINBELL", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("WEEPINBELL", {
        spriteFront = mod.assets:path("overrides/battle/front/weepinbell.png"),
        spriteBack = mod.assets:path("overrides/battle/back/weepinbellb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("VICTREEBEL", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("VICTREEBEL", {
        spriteFront = mod.assets:path("overrides/battle/front/victreebel.png"),
        spriteBack = mod.assets:path("overrides/battle/back/victreebelb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("TENTACOOL", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("TENTACOOL", {
        spriteFront = mod.assets:path("overrides/battle/front/tentacool.png"),
        spriteBack = mod.assets:path("overrides/battle/back/tentacoolb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("TENTACRUEL", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("TENTACRUEL", {
        spriteFront = mod.assets:path("overrides/battle/front/tentacruel.png"),
        spriteBack = mod.assets:path("overrides/battle/back/tentacruelb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("GEODUDE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("GEODUDE", {
        spriteFront = mod.assets:path("overrides/battle/front/geodude.png"),
        spriteBack = mod.assets:path("overrides/battle/back/geodudeb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("GRAVELER", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("GRAVELER", {
        spriteFront = mod.assets:path("overrides/battle/front/graveler.png"),
        spriteBack = mod.assets:path("overrides/battle/back/gravelerb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("GOLEM", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("GOLEM", {
        spriteFront = mod.assets:path("overrides/battle/front/golem.png"),
        spriteBack = mod.assets:path("overrides/battle/back/golemb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("PONYTA", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("PONYTA", {
        spriteFront = mod.assets:path("overrides/battle/front/ponyta.png"),
        spriteBack = mod.assets:path("overrides/battle/back/ponytab.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("RAPIDASH", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("RAPIDASH", {
        spriteFront = mod.assets:path("overrides/battle/front/rapidash.png"),
        spriteBack = mod.assets:path("overrides/battle/back/rapidashb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("SLOWPOKE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("SLOWPOKE", {
        spriteFront = mod.assets:path("overrides/battle/front/slowpoke.png"),
        spriteBack = mod.assets:path("overrides/battle/back/slowpokeb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("SLOWBRO", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("SLOWBRO", {
        spriteFront = mod.assets:path("overrides/battle/front/slowbro.png"),
        spriteBack = mod.assets:path("overrides/battle/back/slowbrob.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("MAGNEMITE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MAGNEMITE", {
        spriteFront = mod.assets:path("overrides/battle/front/magnemite.png"),
        spriteBack = mod.assets:path("overrides/battle/back/magnemiteb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("MAGNETON", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MAGNETON", {
        spriteFront = mod.assets:path("overrides/battle/front/magneton.png"),
        spriteBack = mod.assets:path("overrides/battle/back/magnetonb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("FARFETCHD", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("FARFETCHD", {
        spriteFront = mod.assets:path("overrides/battle/front/farfetchd.png"),
        spriteBack = mod.assets:path("overrides/battle/back/farfetchdb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("DODUO", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("DODUO", {
        spriteFront = mod.assets:path("overrides/battle/front/doduo.png"),
        spriteBack = mod.assets:path("overrides/battle/back/doduob.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("DODRIO", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("DODRIO", {
        spriteFront = mod.assets:path("overrides/battle/front/dodrio.png"),
        spriteBack = mod.assets:path("overrides/battle/back/dodriob.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("SEEL", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("SEEL", {
        spriteFront = mod.assets:path("overrides/battle/front/seel.png"),
        spriteBack = mod.assets:path("overrides/battle/back/seelb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("DEWGONG", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("DEWGONG", {
        spriteFront = mod.assets:path("overrides/battle/front/dewgong.png"),
        spriteBack = mod.assets:path("overrides/battle/back/dewgongb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("GRIMER", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("GRIMER", {
        spriteFront = mod.assets:path("overrides/battle/front/grimer.png"),
        spriteBack = mod.assets:path("overrides/battle/back/grimerb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("MUK", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MUK", {
        spriteFront = mod.assets:path("overrides/battle/front/muk.png"),
        spriteBack = mod.assets:path("overrides/battle/back/mukb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("SHELLDER", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("SHELLDER", {
        spriteFront = mod.assets:path("overrides/battle/front/shellder.png"),
        spriteBack = mod.assets:path("overrides/battle/back/shellderb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("CLOYSTER", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("CLOYSTER", {
        spriteFront = mod.assets:path("overrides/battle/front/cloyster.png"),
        spriteBack = mod.assets:path("overrides/battle/back/cloysterb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("GASTLY", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("GASTLY", {
        spriteFront = mod.assets:path("overrides/battle/front/gastly.png"),
        spriteBack = mod.assets:path("overrides/battle/back/gastlyb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("HAUNTER", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("HAUNTER", {
        spriteFront = mod.assets:path("overrides/battle/front/haunter.png"),
        spriteBack = mod.assets:path("overrides/battle/back/haunterb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("GENGAR", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("GENGAR", {
        spriteFront = mod.assets:path("overrides/battle/front/gengar.png"),
        spriteBack = mod.assets:path("overrides/battle/back/gengarb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("ONIX", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("ONIX", {
        spriteFront = mod.assets:path("overrides/battle/front/onix.png"),
        spriteBack = mod.assets:path("overrides/battle/back/onixb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("DROWZEE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("DROWZEE", {
        spriteFront = mod.assets:path("overrides/battle/front/drowzee.png"),
        spriteBack = mod.assets:path("overrides/battle/back/drowzeeb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("HYPNO", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("HYPNO", {
        spriteFront = mod.assets:path("overrides/battle/front/hypno.png"),
        spriteBack = mod.assets:path("overrides/battle/back/hypnob.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("KRABBY", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("KRABBY", {
        spriteFront = mod.assets:path("overrides/battle/front/krabby.png"),
        spriteBack = mod.assets:path("overrides/battle/back/krabbyb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("KINGLER", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("KINGLER", {
        spriteFront = mod.assets:path("overrides/battle/front/kingler.png"),
        spriteBack = mod.assets:path("overrides/battle/back/kinglerb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("VOLTORB", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("VOLTORB", {
        spriteFront = mod.assets:path("overrides/battle/front/voltorb.png"),
        spriteBack = mod.assets:path("overrides/battle/back/voltorbb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("ELECTRODE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("ELECTRODE", {
        spriteFront = mod.assets:path("overrides/battle/front/electrode.png"),
        spriteBack = mod.assets:path("overrides/battle/back/electrodeb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("EXEGGCUTE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("EXEGGCUTE", {
        spriteFront = mod.assets:path("overrides/battle/front/exeggcute.png"),
        spriteBack = mod.assets:path("overrides/battle/back/exeggcuteb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("EXEGGUTOR", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("EXEGGUTOR", {
        spriteFront = mod.assets:path("overrides/battle/front/exeggutor.png"),
        spriteBack = mod.assets:path("overrides/battle/back/exeggutorb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("CUBONE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("CUBONE", {
        spriteFront = mod.assets:path("overrides/battle/front/cubone.png"),
        spriteBack = mod.assets:path("overrides/battle/back/cuboneb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("MAROWAK", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MAROWAK", {
        spriteFront = mod.assets:path("overrides/battle/front/marowak.png"),
        spriteBack = mod.assets:path("overrides/battle/back/marowakb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("HITMONLEE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("HITMONLEE", {
        spriteFront = mod.assets:path("overrides/battle/front/hitmonlee.png"),
        spriteBack = mod.assets:path("overrides/battle/back/hitmonleeb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("HITMONCHAN", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("HITMONCHAN", {
        spriteFront = mod.assets:path("overrides/battle/front/hitmonchan.png"),
        spriteBack = mod.assets:path("overrides/battle/back/hitmonchanb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("LICKITUNG", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("LICKITUNG", {
        spriteFront = mod.assets:path("overrides/battle/front/lickitung.png"),
        spriteBack = mod.assets:path("overrides/battle/back/lickitungb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("KOFFING", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("KOFFING", {
        spriteFront = mod.assets:path("overrides/battle/front/koffing.png"),
        spriteBack = mod.assets:path("overrides/battle/back/koffingb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("WEEZING", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("WEEZING", {
        spriteFront = mod.assets:path("overrides/battle/front/weezing.png"),
        spriteBack = mod.assets:path("overrides/battle/back/weezingb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("RHYHORN", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("RHYHORN", {
        spriteFront = mod.assets:path("overrides/battle/front/rhyhorn.png"),
        spriteBack = mod.assets:path("overrides/battle/back/rhyhornb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("RHYDON", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("RHYDON", {
        spriteFront = mod.assets:path("overrides/battle/front/rhydon.png"),
        spriteBack = mod.assets:path("overrides/battle/back/rhydonb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("CHANSEY", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("CHANSEY", {
        spriteFront = mod.assets:path("overrides/battle/front/chansey.png"),
        spriteBack = mod.assets:path("overrides/battle/back/chanseyb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("TANGELA", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("TANGELA", {
        spriteFront = mod.assets:path("overrides/battle/front/tangela.png"),
        spriteBack = mod.assets:path("overrides/battle/back/tangelab.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("KANGASKHAN", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("KANGASKHAN", {
        spriteFront = mod.assets:path("overrides/battle/front/kangaskhan.png"),
        spriteBack = mod.assets:path("overrides/battle/back/kangaskhanb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("HORSEA", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("HORSEA", {
        spriteFront = mod.assets:path("overrides/battle/front/horsea.png"),
        spriteBack = mod.assets:path("overrides/battle/back/horseab.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("SEADRA", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("SEADRA", {
        spriteFront = mod.assets:path("overrides/battle/front/seadra.png"),
        spriteBack = mod.assets:path("overrides/battle/back/seadrab.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("GOLDEEN", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("GOLDEEN", {
        spriteFront = mod.assets:path("overrides/battle/front/goldeen.png"),
        spriteBack = mod.assets:path("overrides/battle/back/goldeenb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("SEAKING", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("SEAKING", {
        spriteFront = mod.assets:path("overrides/battle/front/seaking.png"),
        spriteBack = mod.assets:path("overrides/battle/back/seakingb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("STARYU", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("STARYU", {
        spriteFront = mod.assets:path("overrides/battle/front/staryu.png"),
        spriteBack = mod.assets:path("overrides/battle/back/staryub.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("STARMIE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("STARMIE", {
        spriteFront = mod.assets:path("overrides/battle/front/starmie.png"),
        spriteBack = mod.assets:path("overrides/battle/back/starmieb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("MR_MIME", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MR_MIME", {
        spriteFront = mod.assets:path("overrides/battle/front/mr_mime.png"),
        spriteBack = mod.assets:path("overrides/battle/back/mr_mimeb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("SCYTHER", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("SCYTHER", {
        spriteFront = mod.assets:path("overrides/battle/front/scyther.png"),
        spriteBack = mod.assets:path("overrides/battle/back/scytherb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("JYNX", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("JYNX", {
        spriteFront = mod.assets:path("overrides/battle/front/jynx.png"),
        spriteBack = mod.assets:path("overrides/battle/back/jynxb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("ELECTABUZZ", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("ELECTABUZZ", {
        spriteFront = mod.assets:path("overrides/battle/front/electabuzz.png"),
        spriteBack = mod.assets:path("overrides/battle/back/electabuzzb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("MAGMAR", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MAGMAR", {
        spriteFront = mod.assets:path("overrides/battle/front/magmar.png"),
        spriteBack = mod.assets:path("overrides/battle/back/magmarb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("PINSIR", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("PINSIR", {
        spriteFront = mod.assets:path("overrides/battle/front/pinsir.png"),
        spriteBack = mod.assets:path("overrides/battle/back/pinsirb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("TAUROS", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("TAUROS", {
        spriteFront = mod.assets:path("overrides/battle/front/tauros.png"),
        spriteBack = mod.assets:path("overrides/battle/back/taurosb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("MAGIKARP", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MAGIKARP", {
        spriteFront = mod.assets:path("overrides/battle/front/magikarp.png"),
        spriteBack = mod.assets:path("overrides/battle/back/magikarpb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("GYARADOS", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("GYARADOS", {
        spriteFront = mod.assets:path("overrides/battle/front/gyarados.png"),
        spriteBack = mod.assets:path("overrides/battle/back/gyaradosb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("LAPRAS", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("LAPRAS", {
        spriteFront = mod.assets:path("overrides/battle/front/lapras.png"),
        spriteBack = mod.assets:path("overrides/battle/back/laprasb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("DITTO", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("DITTO", {
        spriteFront = mod.assets:path("overrides/battle/front/ditto.png"),
        spriteBack = mod.assets:path("overrides/battle/back/dittob.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("EEVEE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("EEVEE", {
        spriteFront = mod.assets:path("overrides/battle/front/eevee.png"),
        spriteBack = mod.assets:path("overrides/battle/back/eeveeb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("VAPOREON", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("VAPOREON", {
        spriteFront = mod.assets:path("overrides/battle/front/vaporeon.png"),
        spriteBack = mod.assets:path("overrides/battle/back/vaporeonb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("JOLTEON", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("JOLTEON", {
        spriteFront = mod.assets:path("overrides/battle/front/jolteon.png"),
        spriteBack = mod.assets:path("overrides/battle/back/jolteonb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("FLAREON", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("FLAREON", {
        spriteFront = mod.assets:path("overrides/battle/front/flareon.png"),
        spriteBack = mod.assets:path("overrides/battle/back/flareonb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("PORYGON", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("PORYGON", {
        spriteFront = mod.assets:path("overrides/battle/front/porygon.png"),
        spriteBack = mod.assets:path("overrides/battle/back/porygonb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("OMANYTE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("OMANYTE", {
        spriteFront = mod.assets:path("overrides/battle/front/omanyte.png"),
        spriteBack = mod.assets:path("overrides/battle/back/omanyteb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("OMASTAR", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("OMASTAR", {
        spriteFront = mod.assets:path("overrides/battle/front/omastar.png"),
        spriteBack = mod.assets:path("overrides/battle/back/omastarb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("KABUTO", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("KABUTO", {
        spriteFront = mod.assets:path("overrides/battle/front/kabuto.png"),
        spriteBack = mod.assets:path("overrides/battle/back/kabutob.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("KABUTOPS", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("KABUTOPS", {
        spriteFront = mod.assets:path("overrides/battle/front/kabutops.png"),
        spriteBack = mod.assets:path("overrides/battle/back/kabutopsb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("AERODACTYL", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("AERODACTYL", {
        spriteFront = mod.assets:path("overrides/battle/front/aerodactyl.png"),
        spriteBack = mod.assets:path("overrides/battle/back/aerodactylb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("SNORLAX", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("SNORLAX", {
        spriteFront = mod.assets:path("overrides/battle/front/snorlax.png"),
        spriteBack = mod.assets:path("overrides/battle/back/snorlaxb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("ARTICUNO", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("ARTICUNO", {
        spriteFront = mod.assets:path("overrides/battle/front/articuno.png"),
        spriteBack = mod.assets:path("overrides/battle/back/articunob.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("ZAPDOS", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("ZAPDOS", {
        spriteFront = mod.assets:path("overrides/battle/front/zapdos.png"),
        spriteBack = mod.assets:path("overrides/battle/back/zapdosb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("MOLTRES", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MOLTRES", {
        spriteFront = mod.assets:path("overrides/battle/front/moltres.png"),
        spriteBack = mod.assets:path("overrides/battle/back/moltresb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("DRATINI", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("DRATINI", {
        spriteFront = mod.assets:path("overrides/battle/front/dratini.png"),
        spriteBack = mod.assets:path("overrides/battle/back/dratinib.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("DRAGONAIR", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("DRAGONAIR", {
        spriteFront = mod.assets:path("overrides/battle/front/dragonair.png"),
        spriteBack = mod.assets:path("overrides/battle/back/dragonairb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("DRAGONITE", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("DRAGONITE", {
        spriteFront = mod.assets:path("overrides/battle/front/dragonite.png"),
        spriteBack = mod.assets:path("overrides/battle/back/dragoniteb.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("MEWTWO", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MEWTWO", {
        spriteFront = mod.assets:path("overrides/battle/front/mewtwo.png"),
        spriteBack = mod.assets:path("overrides/battle/back/mewtwob.png"),
        trueColor = false
    })

    mod.content.pokemon:patch("MEW", {
    battleScaleBack = 1
})

mod.content.pokemon:patch("MEW", {
        spriteFront = mod.assets:path("overrides/battle/front/mew.png"),
        spriteBack = mod.assets:path("overrides/battle/back/mewb.png"),
        trueColor = false
    })

mod.content.palettes:register("BULBASAUR_PALETTE", { {255,255,255}, {99,255,90}, {255,82,49}, {0,0,0} })
mod.content.palettes:register("IVYSAUR_PALETTE", { {255,255,255}, {99,255,90}, {255,99,140}, {0,0,0} })
mod.content.palettes:register("VENUSAUR_PALETTE", { {255,255,255}, {99,255,156}, {255,74,156}, {0,0,0} })
mod.content.palettes:register("CHARMANDER_PALETTE", { {255,255,255}, {255,148,33}, {181,90,41}, {0,0,0} })
mod.content.palettes:register("CHARMELEON_PALETTE", { {255,255,255}, {255,115,41}, {189,74,82}, {0,0,0} })
mod.content.palettes:register("CHARIZARD_PALETTE", { {255,255,255}, {255,115,0}, {57,90,123}, {0,0,0} })
mod.content.palettes:register("SQUIRTLE_PALETTE", { {255,255,255}, {181,148,66}, {99,156,255}, {0,0,0} })
mod.content.palettes:register("WARTORTLE_PALETTE", { {255,255,255}, {181,148,66}, {99,156,255}, {0,0,0} })
mod.content.palettes:register("BLASTOISE_PALETTE", { {255,255,255}, {198,165,24}, {66,90,255}, {0,0,0} })
mod.content.palettes:register("CATERPIE_PALETTE", { {255,255,255}, {99,181,49}, {255,99,140}, {0,0,0} })
mod.content.palettes:register("METAPOD_PALETTE", { {255,255,255}, {123,255,0}, {74,115,8}, {0,0,0} })
mod.content.palettes:register("BUTTERFREE_PALETTE", { {255,255,255}, {123,231,255}, {206,82,156}, {0,0,0} })
mod.content.palettes:register("WEEDLE_PALETTE", { {255,255,255}, {239,214,41}, {214,57,0}, {0,0,0} })
mod.content.palettes:register("KAKUNA_PALETTE", { {255,255,255}, {255,222,33}, {165,99,57}, {0,0,0} })
mod.content.palettes:register("BEEDRILL_PALETTE", { {255,255,255}, {255,214,49}, {247,33,8}, {0,0,0} })
mod.content.palettes:register("PIDGEY_PALETTE", { {255,255,255}, {255,173,255}, {156,66,16}, {0,0,0} })
mod.content.palettes:register("PIDGEOTTO_PALETTE", { {255,255,255}, {255,123,189}, {156,66,16}, {0,0,0} })
mod.content.palettes:register("PIDGEOT_PALETTE", { {255,255,255}, {255,123,189}, {156,66,16}, {0,0,0} })
mod.content.palettes:register("RATTATA_PALETTE", { {255,255,255}, {181,123,247}, {148,74,140}, {0,0,0} })
mod.content.palettes:register("RATICATE_PALETTE", { {255,255,255}, {214,132,24}, {115,66,24}, {0,0,0} })
mod.content.palettes:register("SPEAROW_PALETTE", { {255,255,255}, {239,189,107}, {173,66,90}, {0,0,0} })
mod.content.palettes:register("FEAROW_PALETTE", { {255,255,255}, {181,140,57}, {255,90,0}, {0,0,0} })
mod.content.palettes:register("EKANS_PALETTE", { {255,255,255}, {255,107,189}, {189,24,140}, {0,0,0} })
mod.content.palettes:register("ARBOK_PALETTE", { {255,255,255}, {148,66,156}, {181,33,74}, {0,0,0} })
mod.content.palettes:register("PIKACHU_PALETTE", { {255,255,255}, {239,214,41}, {214,49,0}, {0,0,0} })
mod.content.palettes:register("RAICHU_PALETTE", { {255,255,255}, {255,214,57}, {255,99,0}, {0,0,0} })
mod.content.palettes:register("SANDSHREW_PALETTE", { {255,255,255}, {173,132,82}, {115,66,8}, {0,0,0} })
mod.content.palettes:register("SANDSLASH_PALETTE", { {255,255,255}, {189,115,33}, {107,57,0}, {0,0,0} })
mod.content.palettes:register("NIDORAN♀_PALETTE", { {255,255,255}, {156,173,255}, {57,132,49}, {0,0,0} })
mod.content.palettes:register("NIDORINA_PALETTE", { {255,255,255}, {132,173,255}, {57,99,115}, {0,0,0} })
mod.content.palettes:register("NIDOQUEEN_PALETTE", { {255,255,255}, {181,173,49}, {57,132,206}, {0,0,0} })
mod.content.palettes:register("NIDORAN♂_PALETTE", { {255,255,255}, {222,140,181}, {173,16,66}, {0,0,0} })
mod.content.palettes:register("NIDORINO_PALETTE", { {255,255,255}, {214,140,181}, {173,16,66}, {0,0,0} })
mod.content.palettes:register("NIDOKING_PALETTE", { {255,255,255}, {198,82,156}, {107,24,123}, {0,0,0} })
mod.content.palettes:register("CLEFAIRY_PALETTE", { {255,255,255}, {255,107,206}, {107,57,0}, {0,0,0} })
mod.content.palettes:register("CLEFABLE_PALETTE", { {255,255,255}, {255,107,206}, {107,57,0}, {0,0,0} })
mod.content.palettes:register("VULPIX_PALETTE", { {255,255,255}, {255,148,74}, {189,74,82}, {0,0,0} })
mod.content.palettes:register("NINETALES_PALETTE", { {255,255,255}, {255,206,74}, {148,123,0}, {0,0,0} })
mod.content.palettes:register("JIGGLYPUFF_PALETTE", { {255,255,255}, {255,132,255}, {49,132,255}, {0,0,0} })
mod.content.palettes:register("WIGGLYTUFF_PALETTE", { {255,255,255}, {255,132,255}, {49,132,255}, {0,0,0} })
mod.content.palettes:register("ZUBAT_PALETTE", { {255,255,255}, {123,123,222}, {49,57,99}, {0,0,0} })
mod.content.palettes:register("GOLBAT_PALETTE", { {255,255,255}, {148,66,173}, {33,74,123}, {0,0,0} })
mod.content.palettes:register("ODDISH_PALETTE", { {255,255,255}, {107,189,49}, {57,74,132}, {0,0,0} })
mod.content.palettes:register("GLOOM_PALETTE", { {255,255,255}, {255,115,57}, {66,74,107}, {0,0,0} })
mod.content.palettes:register("VILEPLUME_PALETTE", { {255,255,255}, {255,49,24}, {66,74,107}, {0,0,0} })
mod.content.palettes:register("PARAS_PALETTE", { {255,255,255}, {255,99,24}, {231,57,49}, {0,0,0} })
mod.content.palettes:register("PARASECT_PALETTE", { {255,255,255}, {255,74,33}, {115,41,8}, {0,0,0} })
mod.content.palettes:register("VENONAT_PALETTE", { {255,255,255}, {255,74,41}, {90,0,115}, {0,0,0} })
mod.content.palettes:register("VENOMOTH_PALETTE", { {255,255,255}, {222,82,198}, {90,99,115}, {0,0,0} })
mod.content.palettes:register("DIGLETT_PALETTE", { {255,255,255}, {156,90,33}, {198,49,33}, {0,0,0} })
mod.content.palettes:register("DUGTRIO_PALETTE", { {255,255,255}, {156,90,33}, {198,49,33}, {0,0,0} })
mod.content.palettes:register("MEOWTH_PALETTE", { {255,255,255}, {255,255,41}, {231,82,41}, {0,0,0} })
mod.content.palettes:register("PERSIAN_PALETTE", { {255,255,255}, {255,231,82}, {99,74,33}, {0,0,0} })
mod.content.palettes:register("PSYDUCK_PALETTE", { {255,255,255}, {255,222,33}, {140,123,0}, {0,0,0} })
mod.content.palettes:register("GOLDUCK_PALETTE", { {255,255,255}, {222,189,33}, {99,74,198}, {0,0,0} })
mod.content.palettes:register("MANKEY_PALETTE", { {255,255,255}, {239,165,90}, {156,74,57}, {0,0,0} })
mod.content.palettes:register("PRIMEAPE_PALETTE", { {255,255,255}, {255,123,49}, {115,74,33}, {0,0,0} })
mod.content.palettes:register("GROWLITHE_PALETTE", { {255,255,255}, {255,189,57}, {255,74,33}, {0,0,0} })
mod.content.palettes:register("ARCANINE_PALETTE", { {255,255,255}, {255,189,57}, {255,74,33}, {0,0,0} })
mod.content.palettes:register("POLIWAG_PALETTE", { {255,255,255}, {214,66,140}, {66,41,123}, {0,0,0} })
mod.content.palettes:register("POLIWHIRL_PALETTE", { {255,255,255}, {132,132,214}, {66,41,123}, {0,0,0} })
mod.content.palettes:register("POLIWRATH_PALETTE", { {255,255,255}, {132,132,214}, {66,41,123}, {0,0,0} })
mod.content.palettes:register("ABRA_PALETTE", { {255,255,255}, {231,156,24}, {99,66,82}, {0,0,0} })
mod.content.palettes:register("KADABRA_PALETTE", { {255,255,255}, {231,156,24}, {99,66,82}, {0,0,0} })
mod.content.palettes:register("ALAKAZAM_PALETTE", { {255,255,255}, {231,156,24}, {99,66,82}, {0,0,0} })
mod.content.palettes:register("MACHOP_PALETTE", { {255,255,255}, {165,140,90}, {74,90,33}, {0,0,0} })
mod.content.palettes:register("MACHOKE_PALETTE", { {255,255,255}, {132,140,90}, {181,33,33}, {0,0,0} })
mod.content.palettes:register("MACHAMP_PALETTE", { {255,255,255}, {173,148,90}, {74,90,33}, {0,0,0} })
mod.content.palettes:register("BELLSPROUT_PALETTE", { {255,255,255}, {165,255,57}, {222,82,74}, {0,0,0} })
mod.content.palettes:register("WEEPINBELL_PALETTE", { {255,255,255}, {107,255,57}, {239,74,74}, {0,0,0} })
mod.content.palettes:register("VICTREEBEL_PALETTE", { {255,255,255}, {123,214,24}, {255,74,156}, {0,0,0} })
mod.content.palettes:register("TENTACOOL_PALETTE", { {255,255,255}, {90,165,255}, {247,49,82}, {0,0,0} })
mod.content.palettes:register("TENTACRUEL_PALETTE", { {255,255,255}, {90,165,255}, {214,16,16}, {0,0,0} })
mod.content.palettes:register("GEODUDE_PALETTE", { {255,255,255}, {148,140,123}, {66,90,57}, {0,0,0} })
mod.content.palettes:register("GRAVELER_PALETTE", { {255,255,255}, {148,140,123}, {66,90,57}, {0,0,0} })
mod.content.palettes:register("GOLEM_PALETTE", { {255,255,255}, {148,140,123}, {66,90,57}, {0,0,0} })
mod.content.palettes:register("PONYTA_PALETTE", { {255,255,255}, {255,156,0}, {255,90,24}, {0,0,0} })
mod.content.palettes:register("RAPIDASH_PALETTE", { {255,255,255}, {247,231,0}, {255,90,24}, {0,0,0} })
mod.content.palettes:register("SLOWPOKE_PALETTE", { {255,255,255}, {255,82,255}, {231,49,115}, {0,0,0} })
mod.content.palettes:register("SLOWBRO_PALETTE", { {255,255,255}, {255,82,255}, {115,156,99}, {0,0,0} })
mod.content.palettes:register("MAGNEMITE_PALETTE", { {255,255,255}, {90,165,255}, {255,49,16}, {0,0,0} })
mod.content.palettes:register("MAGNETON_PALETTE", { {255,255,255}, {90,165,255}, {255,49,16}, {0,0,0} })
mod.content.palettes:register("FARFETCH'D_PALETTE", { {255,255,255}, {189,99,66}, {49,214,8}, {0,0,0} })
mod.content.palettes:register("DODUO_PALETTE", { {255,255,255}, {165,132,66}, {74,66,49}, {0,0,0} })
mod.content.palettes:register("DODRIO_PALETTE", { {255,255,255}, {214,132,66}, {148,66,49}, {0,0,0} })
mod.content.palettes:register("SEEL_PALETTE", { {255,255,255}, {156,173,255}, {239,90,148}, {0,0,0} })
mod.content.palettes:register("DEWGONG_PALETTE", { {255,255,255}, {156,173,255}, {66,90,148}, {0,0,0} })
mod.content.palettes:register("GRIMER_PALETTE", { {255,255,255}, {239,16,165}, {99,8,99}, {0,0,0} })
mod.content.palettes:register("MUK_PALETTE", { {255,255,255}, {239,16,165}, {99,8,99}, {0,0,0} })
mod.content.palettes:register("SHELLDER_PALETTE", { {255,255,255}, {148,140,165}, {173,90,115}, {0,0,0} })
mod.content.palettes:register("CLOYSTER_PALETTE", { {255,255,255}, {156,82,206}, {74,33,107}, {0,0,0} })
mod.content.palettes:register("GASTLY_PALETTE", { {255,255,255}, {247,107,247}, {140,0,189}, {0,0,0} })
mod.content.palettes:register("HAUNTER_PALETTE", { {255,255,255}, {206,57,49}, {115,0,156}, {0,0,0} })
mod.content.palettes:register("GENGAR_PALETTE", { {255,255,255}, {255,66,16}, {140,0,156}, {0,0,0} })
mod.content.palettes:register("ONIX_PALETTE", { {255,255,255}, {189,148,140}, {74,49,90}, {0,0,0} })
mod.content.palettes:register("DROWZEE_PALETTE", { {255,255,255}, {255,189,33}, {148,82,99}, {0,0,0} })
mod.content.palettes:register("HYPNO_PALETTE", { {255,255,255}, {247,165,57}, {156,99,90}, {0,0,0} })
mod.content.palettes:register("KRABBY_PALETTE", { {255,255,255}, {239,140,74}, {239,41,33}, {0,0,0} })
mod.content.palettes:register("KINGLER_PALETTE", { {255,255,255}, {239,140,74}, {239,41,33}, {0,0,0} })
mod.content.palettes:register("VOLTORB_PALETTE", { {255,255,255}, {206,189,140}, {255,74,66}, {0,0,0} })
mod.content.palettes:register("ELECTRODE_PALETTE", { {255,255,255}, {206,189,140}, {255,74,66}, {0,0,0} })
mod.content.palettes:register("EXEGGCUTE_PALETTE", { {255,255,255}, {255,123,214}, {156,99,74}, {0,0,0} })
mod.content.palettes:register("EXEGGUTOR_PALETTE", { {255,255,255}, {214,132,49}, {41,132,57}, {0,0,0} })
mod.content.palettes:register("CUBONE_PALETTE", { {255,255,255}, {181,132,90}, {115,66,33}, {0,0,0} })
mod.content.palettes:register("MAROWAK_PALETTE", { {255,255,255}, {181,132,90}, {115,66,33}, {0,0,0} })
mod.content.palettes:register("HITMONLEE_PALETTE", { {255,255,255}, {181,115,41}, {123,132,123}, {0,0,0} })
mod.content.palettes:register("HITMONCHAN_PALETTE", { {255,255,255}, {173,123,99}, {222,24,148}, {0,0,0} })
mod.content.palettes:register("LICKITUNG_PALETTE", { {255,255,255}, {255,82,148}, {214,49,41}, {0,0,0} })
mod.content.palettes:register("KOFFING_PALETTE", { {255,255,255}, {206,82,206}, {148,49,148}, {0,0,0} })
mod.content.palettes:register("WEEZING_PALETTE", { {255,255,255}, {206,82,206}, {148,49,148}, {0,0,0} })
mod.content.palettes:register("RHYHORN_PALETTE", { {255,255,255}, {123,90,140}, {57,74,33}, {0,0,0} })
mod.content.palettes:register("RHYDON_PALETTE", { {255,255,255}, {123,90,140}, {57,74,33}, {0,0,0} })
mod.content.palettes:register("CHANSEY_PALETTE", { {255,255,255}, {222,156,189}, {255,66,173}, {0,0,0} })
mod.content.palettes:register("TANGELA_PALETTE", { {255,255,255}, {8,255,198}, {140,49,49}, {0,0,0} })
mod.content.palettes:register("KANGASKHAN_PALETTE", { {255,255,255}, {165,156,57}, {107,107,0}, {0,0,0} })
mod.content.palettes:register("HORSEA_PALETTE", { {255,255,255}, {231,222,99}, {90,140,255}, {0,0,0} })
mod.content.palettes:register("SEADRA_PALETTE", { {255,255,255}, {231,165,99}, {90,74,255}, {0,0,0} })
mod.content.palettes:register("GOLDEEN_PALETTE", { {255,255,255}, {255,99,156}, {255,82,16}, {0,0,0} })
mod.content.palettes:register("SEAKING_PALETTE", { {255,255,255}, {156,181,247}, {255,82,16}, {0,0,0} })
mod.content.palettes:register("STARYU_PALETTE", { {255,255,255}, {189,140,90}, {255,41,24}, {0,0,0} })
mod.content.palettes:register("STARMIE_PALETTE", { {255,255,255}, {214,181,0}, {156,57,148}, {0,0,0} })
mod.content.palettes:register("MR.MIME_PALETTE", { {255,255,255}, {255,90,255}, {231,57,107}, {0,0,0} })
mod.content.palettes:register("SCYTHER_PALETTE", { {255,255,255}, {123,214,0}, {189,206,0}, {0,0,0} })
mod.content.palettes:register("JYNX_PALETTE", { {255,255,255}, {239,49,156}, {115,16,123}, {0,0,0} })
mod.content.palettes:register("ELECTABUZZ_PALETTE", { {255,255,255}, {255,255,41}, {198,132,41}, {0,0,0} })
mod.content.palettes:register("MAGMAR_PALETTE", { {255,255,255}, {255,165,0}, {189,74,82}, {0,0,0} })
mod.content.palettes:register("PINSIR_PALETTE", { {255,255,255}, {148,173,148}, {132,90,57}, {0,0,0} })
mod.content.palettes:register("TAUROS_PALETTE", { {255,255,255}, {255,198,41}, {156,115,74}, {0,0,0} })
mod.content.palettes:register("MAGIKARP_PALETTE", { {255,255,255}, {239,82,49}, {148,24,74}, {0,0,0} })
mod.content.palettes:register("GYARADOS_PALETTE", { {255,255,255}, {222,165,57}, {57,90,214}, {0,0,0} })
mod.content.palettes:register("LAPRAS_PALETTE", { {255,255,255}, {231,173,107}, {66,132,231}, {0,0,0} })
mod.content.palettes:register("DITTO_PALETTE", { {255,255,255}, {189,99,231}, {107,57,132}, {0,0,0} })
mod.content.palettes:register("EEVEE_PALETTE", { {255,255,255}, {198,132,90}, {140,82,66}, {0,0,0} })
mod.content.palettes:register("VAPOREON_PALETTE", { {255,255,255}, {132,181,255}, {74,90,255}, {0,0,0} })
mod.content.palettes:register("JOLTEON_PALETTE", { {255,255,255}, {255,255,24}, {231,90,8}, {0,0,0} })
mod.content.palettes:register("FLAREON_PALETTE", { {255,255,255}, {255,82,8}, {173,41,16}, {0,0,0} })
mod.content.palettes:register("PORYGON_PALETTE", { {255,255,255}, {198,74,33}, {99,90,206}, {0,0,0} })
mod.content.palettes:register("OMANYTE_PALETTE", { {255,255,255}, {189,165,82}, {74,90,189}, {0,0,0} })
mod.content.palettes:register("OMASTAR_PALETTE", { {255,255,255}, {222,181,90}, {74,90,189}, {0,0,0} })
mod.content.palettes:register("KABUTO_PALETTE", { {255,255,255}, {189,123,90}, {115,90,66}, {0,0,0} })
mod.content.palettes:register("KABUTOPS_PALETTE", { {255,255,255}, {189,123,90}, {115,90,66}, {0,0,0} })
mod.content.palettes:register("AERODACTYL_PALETTE", { {255,255,255}, {173,123,148}, {107,90,66}, {0,0,0} })
mod.content.palettes:register("SNORLAX_PALETTE", { {255,255,255}, {222,148,115}, {173,57,115}, {0,0,0} })
mod.content.palettes:register("ARTICUNO_PALETTE", { {255,255,255}, {90,173,255}, {66,90,132}, {0,0,0} })
mod.content.palettes:register("ZAPDOS_PALETTE", { {255,255,255}, {255,231,0}, {189,132,0}, {0,0,0} })
mod.content.palettes:register("MOLTRES_PALETTE", { {255,255,255}, {255,181,0}, {255,99,24}, {0,0,0} })
mod.content.palettes:register("DRATINI_PALETTE", { {255,255,255}, {231,214,57}, {41,90,198}, {0,0,0} })
mod.content.palettes:register("DRAGONAIR_PALETTE", { {255,255,255}, {115,156,255}, {41,90,255}, {0,0,0} })
mod.content.palettes:register("DRAGONITE_PALETTE", { {255,255,255}, {173,148,49}, {90,82,140}, {0,0,0} })
mod.content.palettes:register("MEWTWO_PALETTE", { {255,255,255}, {181,165,206}, {140,66,123}, {0,0,0} })
mod.content.palettes:register("MEW_PALETTE", { {255,255,255}, {255,123,255}, {57,90,214}, {0,0,0} })


mod.content.pokemon:patch("BULBASAUR", {palette = "BULBASAUR_PALETTE"})
mod.content.pokemon:patch("IVYSAUR", {palette = "IVYSAUR_PALETTE"})
mod.content.pokemon:patch("VENUSAUR", {palette = "VENUSAUR_PALETTE"})
mod.content.pokemon:patch("CHARMANDER", {palette = "CHARMANDER_PALETTE"})
mod.content.pokemon:patch("CHARMELEON", {palette = "CHARMELEON_PALETTE"})
mod.content.pokemon:patch("CHARIZARD", {palette = "CHARIZARD_PALETTE"})
mod.content.pokemon:patch("SQUIRTLE", {palette = "SQUIRTLE_PALETTE"})
mod.content.pokemon:patch("WARTORTLE", {palette = "WARTORTLE_PALETTE"})
mod.content.pokemon:patch("BLASTOISE", {palette = "BLASTOISE_PALETTE"})
mod.content.pokemon:patch("CATERPIE", {palette = "CATERPIE_PALETTE"})
mod.content.pokemon:patch("METAPOD", {palette = "METAPOD_PALETTE"})
mod.content.pokemon:patch("BUTTERFREE", {palette = "BUTTERFREE_PALETTE"})
mod.content.pokemon:patch("WEEDLE", {palette = "WEEDLE_PALETTE"})
mod.content.pokemon:patch("KAKUNA", {palette = "KAKUNA_PALETTE"})
mod.content.pokemon:patch("BEEDRILL", {palette = "BEEDRILL_PALETTE"})
mod.content.pokemon:patch("PIDGEY", {palette = "PIDGEY_PALETTE"})
mod.content.pokemon:patch("PIDGEOTTO", {palette = "PIDGEOTTO_PALETTE"})
mod.content.pokemon:patch("PIDGEOT", {palette = "PIDGEOT_PALETTE"})
mod.content.pokemon:patch("RATTATA", {palette = "RATTATA_PALETTE"})
mod.content.pokemon:patch("RATICATE", {palette = "RATICATE_PALETTE"})
mod.content.pokemon:patch("SPEAROW", {palette = "SPEAROW_PALETTE"})
mod.content.pokemon:patch("FEAROW", {palette = "FEAROW_PALETTE"})
mod.content.pokemon:patch("EKANS", {palette = "EKANS_PALETTE"})
mod.content.pokemon:patch("ARBOK", {palette = "ARBOK_PALETTE"})
mod.content.pokemon:patch("PIKACHU", {palette = "PIKACHU_PALETTE"})
mod.content.pokemon:patch("RAICHU", {palette = "RAICHU_PALETTE"})
mod.content.pokemon:patch("SANDSHREW", {palette = "SANDSHREW_PALETTE"})
mod.content.pokemon:patch("SANDSLASH", {palette = "SANDSLASH_PALETTE"})
mod.content.pokemon:patch("NIDORAN♀", {palette = "NIDORAN♀_PALETTE"})
mod.content.pokemon:patch("NIDORINA", {palette = "NIDORINA_PALETTE"})
mod.content.pokemon:patch("NIDOQUEEN", {palette = "NIDOQUEEN_PALETTE"})
mod.content.pokemon:patch("NIDORAN♂", {palette = "NIDORAN♂_PALETTE"})
mod.content.pokemon:patch("NIDORINO", {palette = "NIDORINO_PALETTE"})
mod.content.pokemon:patch("NIDOKING", {palette = "NIDOKING_PALETTE"})
mod.content.pokemon:patch("CLEFAIRY", {palette = "CLEFAIRY_PALETTE"})
mod.content.pokemon:patch("CLEFABLE", {palette = "CLEFABLE_PALETTE"})
mod.content.pokemon:patch("VULPIX", {palette = "VULPIX_PALETTE"})
mod.content.pokemon:patch("NINETALES", {palette = "NINETALES_PALETTE"})
mod.content.pokemon:patch("JIGGLYPUFF", {palette = "JIGGLYPUFF_PALETTE"})
mod.content.pokemon:patch("WIGGLYTUFF", {palette = "WIGGLYTUFF_PALETTE"})
mod.content.pokemon:patch("ZUBAT", {palette = "ZUBAT_PALETTE"})
mod.content.pokemon:patch("GOLBAT", {palette = "GOLBAT_PALETTE"})
mod.content.pokemon:patch("ODDISH", {palette = "ODDISH_PALETTE"})
mod.content.pokemon:patch("GLOOM", {palette = "GLOOM_PALETTE"})
mod.content.pokemon:patch("VILEPLUME", {palette = "VILEPLUME_PALETTE"})
mod.content.pokemon:patch("PARAS", {palette = "PARAS_PALETTE"})
mod.content.pokemon:patch("PARASECT", {palette = "PARASECT_PALETTE"})
mod.content.pokemon:patch("VENONAT", {palette = "VENONAT_PALETTE"})
mod.content.pokemon:patch("VENOMOTH", {palette = "VENOMOTH_PALETTE"})
mod.content.pokemon:patch("DIGLETT", {palette = "DIGLETT_PALETTE"})
mod.content.pokemon:patch("DUGTRIO", {palette = "DUGTRIO_PALETTE"})
mod.content.pokemon:patch("MEOWTH", {palette = "MEOWTH_PALETTE"})
mod.content.pokemon:patch("PERSIAN", {palette = "PERSIAN_PALETTE"})
mod.content.pokemon:patch("PSYDUCK", {palette = "PSYDUCK_PALETTE"})
mod.content.pokemon:patch("GOLDUCK", {palette = "GOLDUCK_PALETTE"})
mod.content.pokemon:patch("MANKEY", {palette = "MANKEY_PALETTE"})
mod.content.pokemon:patch("PRIMEAPE", {palette = "PRIMEAPE_PALETTE"})
mod.content.pokemon:patch("GROWLITHE", {palette = "GROWLITHE_PALETTE"})
mod.content.pokemon:patch("ARCANINE", {palette = "ARCANINE_PALETTE"})
mod.content.pokemon:patch("POLIWAG", {palette = "POLIWAG_PALETTE"})
mod.content.pokemon:patch("POLIWHIRL", {palette = "POLIWHIRL_PALETTE"})
mod.content.pokemon:patch("POLIWRATH", {palette = "POLIWRATH_PALETTE"})
mod.content.pokemon:patch("ABRA", {palette = "ABRA_PALETTE"})
mod.content.pokemon:patch("KADABRA", {palette = "KADABRA_PALETTE"})
mod.content.pokemon:patch("ALAKAZAM", {palette = "ALAKAZAM_PALETTE"})
mod.content.pokemon:patch("MACHOP", {palette = "MACHOP_PALETTE"})
mod.content.pokemon:patch("MACHOKE", {palette = "MACHOKE_PALETTE"})
mod.content.pokemon:patch("MACHAMP", {palette = "MACHAMP_PALETTE"})
mod.content.pokemon:patch("BELLSPROUT", {palette = "BELLSPROUT_PALETTE"})
mod.content.pokemon:patch("WEEPINBELL", {palette = "WEEPINBELL_PALETTE"})
mod.content.pokemon:patch("VICTREEBEL", {palette = "VICTREEBEL_PALETTE"})
mod.content.pokemon:patch("TENTACOOL", {palette = "TENTACOOL_PALETTE"})
mod.content.pokemon:patch("TENTACRUEL", {palette = "TENTACRUEL_PALETTE"})
mod.content.pokemon:patch("GEODUDE", {palette = "GEODUDE_PALETTE"})
mod.content.pokemon:patch("GRAVELER", {palette = "GRAVELER_PALETTE"})
mod.content.pokemon:patch("GOLEM", {palette = "GOLEM_PALETTE"})
mod.content.pokemon:patch("PONYTA", {palette = "PONYTA_PALETTE"})
mod.content.pokemon:patch("RAPIDASH", {palette = "RAPIDASH_PALETTE"})
mod.content.pokemon:patch("SLOWPOKE", {palette = "SLOWPOKE_PALETTE"})
mod.content.pokemon:patch("SLOWBRO", {palette = "SLOWBRO_PALETTE"})
mod.content.pokemon:patch("MAGNEMITE", {palette = "MAGNEMITE_PALETTE"})
mod.content.pokemon:patch("MAGNETON", {palette = "MAGNETON_PALETTE"})
mod.content.pokemon:patch("FARFETCH'D", {palette = "FARFETCH'D_PALETTE"})
mod.content.pokemon:patch("DODUO", {palette = "DODUO_PALETTE"})
mod.content.pokemon:patch("DODRIO", {palette = "DODRIO_PALETTE"})
mod.content.pokemon:patch("SEEL", {palette = "SEEL_PALETTE"})
mod.content.pokemon:patch("DEWGONG", {palette = "DEWGONG_PALETTE"})
mod.content.pokemon:patch("GRIMER", {palette = "GRIMER_PALETTE"})
mod.content.pokemon:patch("MUK", {palette = "MUK_PALETTE"})
mod.content.pokemon:patch("SHELLDER", {palette = "SHELLDER_PALETTE"})
mod.content.pokemon:patch("CLOYSTER", {palette = "CLOYSTER_PALETTE"})
mod.content.pokemon:patch("GASTLY", {palette = "GASTLY_PALETTE"})
mod.content.pokemon:patch("HAUNTER", {palette = "HAUNTER_PALETTE"})
mod.content.pokemon:patch("GENGAR", {palette = "GENGAR_PALETTE"})
mod.content.pokemon:patch("ONIX", {palette = "ONIX_PALETTE"})
mod.content.pokemon:patch("DROWZEE", {palette = "DROWZEE_PALETTE"})
mod.content.pokemon:patch("HYPNO", {palette = "HYPNO_PALETTE"})
mod.content.pokemon:patch("KRABBY", {palette = "KRABBY_PALETTE"})
mod.content.pokemon:patch("KINGLER", {palette = "KINGLER_PALETTE"})
mod.content.pokemon:patch("VOLTORB", {palette = "VOLTORB_PALETTE"})
mod.content.pokemon:patch("ELECTRODE", {palette = "ELECTRODE_PALETTE"})
mod.content.pokemon:patch("EXEGGCUTE", {palette = "EXEGGCUTE_PALETTE"})
mod.content.pokemon:patch("EXEGGUTOR", {palette = "EXEGGUTOR_PALETTE"})
mod.content.pokemon:patch("CUBONE", {palette = "CUBONE_PALETTE"})
mod.content.pokemon:patch("MAROWAK", {palette = "MAROWAK_PALETTE"})
mod.content.pokemon:patch("HITMONLEE", {palette = "HITMONLEE_PALETTE"})
mod.content.pokemon:patch("HITMONCHAN", {palette = "HITMONCHAN_PALETTE"})
mod.content.pokemon:patch("LICKITUNG", {palette = "LICKITUNG_PALETTE"})
mod.content.pokemon:patch("KOFFING", {palette = "KOFFING_PALETTE"})
mod.content.pokemon:patch("WEEZING", {palette = "WEEZING_PALETTE"})
mod.content.pokemon:patch("RHYHORN", {palette = "RHYHORN_PALETTE"})
mod.content.pokemon:patch("RHYDON", {palette = "RHYDON_PALETTE"})
mod.content.pokemon:patch("CHANSEY", {palette = "CHANSEY_PALETTE"})
mod.content.pokemon:patch("TANGELA", {palette = "TANGELA_PALETTE"})
mod.content.pokemon:patch("KANGASKHAN", {palette = "KANGASKHAN_PALETTE"})
mod.content.pokemon:patch("HORSEA", {palette = "HORSEA_PALETTE"})
mod.content.pokemon:patch("SEADRA", {palette = "SEADRA_PALETTE"})
mod.content.pokemon:patch("GOLDEEN", {palette = "GOLDEEN_PALETTE"})
mod.content.pokemon:patch("SEAKING", {palette = "SEAKING_PALETTE"})
mod.content.pokemon:patch("STARYU", {palette = "STARYU_PALETTE"})
mod.content.pokemon:patch("STARMIE", {palette = "STARMIE_PALETTE"})
mod.content.pokemon:patch("MR.MIME", {palette = "MR.MIME_PALETTE"})
mod.content.pokemon:patch("SCYTHER", {palette = "SCYTHER_PALETTE"})
mod.content.pokemon:patch("JYNX", {palette = "JYNX_PALETTE"})
mod.content.pokemon:patch("ELECTABUZZ", {palette = "ELECTABUZZ_PALETTE"})
mod.content.pokemon:patch("MAGMAR", {palette = "MAGMAR_PALETTE"})
mod.content.pokemon:patch("PINSIR", {palette = "PINSIR_PALETTE"})
mod.content.pokemon:patch("TAUROS", {palette = "TAUROS_PALETTE"})
mod.content.pokemon:patch("MAGIKARP", {palette = "MAGIKARP_PALETTE"})
mod.content.pokemon:patch("GYARADOS", {palette = "GYARADOS_PALETTE"})
mod.content.pokemon:patch("LAPRAS", {palette = "LAPRAS_PALETTE"})
mod.content.pokemon:patch("DITTO", {palette = "DITTO_PALETTE"})
mod.content.pokemon:patch("EEVEE", {palette = "EEVEE_PALETTE"})
mod.content.pokemon:patch("VAPOREON", {palette = "VAPOREON_PALETTE"})
mod.content.pokemon:patch("JOLTEON", {palette = "JOLTEON_PALETTE"})
mod.content.pokemon:patch("FLAREON", {palette = "FLAREON_PALETTE"})
mod.content.pokemon:patch("PORYGON", {palette = "PORYGON_PALETTE"})
mod.content.pokemon:patch("OMANYTE", {palette = "OMANYTE_PALETTE"})
mod.content.pokemon:patch("OMASTAR", {palette = "OMASTAR_PALETTE"})
mod.content.pokemon:patch("KABUTO", {palette = "KABUTO_PALETTE"})
mod.content.pokemon:patch("KABUTOPS", {palette = "KABUTOPS_PALETTE"})
mod.content.pokemon:patch("AERODACTYL", {palette = "AERODACTYL_PALETTE"})
mod.content.pokemon:patch("SNORLAX", {palette = "SNORLAX_PALETTE"})
mod.content.pokemon:patch("ARTICUNO", {palette = "ARTICUNO_PALETTE"})
mod.content.pokemon:patch("ZAPDOS", {palette = "ZAPDOS_PALETTE"})
mod.content.pokemon:patch("MOLTRES", {palette = "MOLTRES_PALETTE"})
mod.content.pokemon:patch("DRATINI", {palette = "DRATINI_PALETTE"})
mod.content.pokemon:patch("DRAGONAIR", {palette = "DRAGONAIR_PALETTE"})
mod.content.pokemon:patch("DRAGONITE", {palette = "DRAGONITE_PALETTE"})
mod.content.pokemon:patch("MEWTWO", {palette = "MEWTWO_PALETTE"})
mod.content.pokemon:patch("MEW", {palette = "MEW_PALETTE"})

end